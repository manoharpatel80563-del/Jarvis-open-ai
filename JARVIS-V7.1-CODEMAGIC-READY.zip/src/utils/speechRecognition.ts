/**
 * Speech Recognition Wrapper for JARVIS V5
 */

export interface SpeechRecognitionResultPayload {
  transcript: string;
  isFinal: boolean;
}

export interface SpeechRecognitionCallbacks {
  onStart?: () => void;
  onTranscript?: (payload: SpeechRecognitionResultPayload) => void;
  onError?: (errorMessage: string, code?: string) => void;
  onEnd?: () => void;
}

export class JarvisSpeechRecognizer {
  private recognition: any = null;
  private isListening = false;
  private safetyTimeout: number | null = null;
  private lang = 'hi-IN';
  private callbacks: SpeechRecognitionCallbacks = {};

  public static isSupported(): boolean {
    return typeof window !== 'undefined' && Boolean((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition);
  }

  constructor(lang = 'hi-IN') {
    this.lang = lang;
    this.init();
  }

  private init() {
    if (typeof window === 'undefined') return;
    const SpeechRecognitionAPI = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognitionAPI) return;

    try {
      this.recognition = new SpeechRecognitionAPI();
      this.recognition.continuous = false; // Single command per activation for mobile stability
      this.recognition.interimResults = true;
      this.recognition.maxAlternatives = 1;
      this.recognition.lang = this.lang;

      this.recognition.onstart = () => {
        this.isListening = true;
        this.clearSafetyTimeout();
        // Safety timeout: automatically stop after 15 seconds of silence or stall
        this.safetyTimeout = window.setTimeout(() => {
          if (this.isListening) {
            this.stop();
          }
        }, 15000);

        this.callbacks.onStart?.();
      };

      this.recognition.onresult = (event: any) => {
        this.clearSafetyTimeout();
        // Extend timeout while actively hearing words
        this.safetyTimeout = window.setTimeout(() => {
          if (this.isListening) {
            this.stop();
          }
        }, 8000);

        let interimTranscript = '';
        let finalTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          const item = event.results[i];
          if (item.isFinal) {
            finalTranscript += item[0].transcript;
          } else {
            interimTranscript += item[0].transcript;
          }
        }

        const activeTranscript = finalTranscript || interimTranscript;
        if (activeTranscript.trim()) {
          this.callbacks.onTranscript?.({
            transcript: activeTranscript.trim(),
            isFinal: Boolean(finalTranscript),
          });
        }
      };

      this.recognition.onerror = (event: any) => {
        console.warn('Speech recognition error event:', event.error);
        this.clearSafetyTimeout();
        this.isListening = false;

        let userMsg = 'Mic error: ' + (event.error || 'unknown');
        if (event.error === 'not-allowed') {
          userMsg = 'Microphone permission denied. Please allow microphone access in your browser settings.';
        } else if (event.error === 'no-speech') {
          userMsg = 'No speech was detected. Tap the mic and try again.';
        } else if (event.error === 'network') {
          userMsg = 'Speech service network error. Please check your internet connection.';
        } else if (event.error === 'audio-capture') {
          userMsg = 'No microphone device was found or audio capture failed.';
        }

        this.callbacks.onError?.(userMsg, event.error);
      };

      this.recognition.onend = () => {
        this.clearSafetyTimeout();
        this.isListening = false;
        this.callbacks.onEnd?.();
      };
    } catch (err) {
      console.error('Failed to initialize SpeechRecognition:', err);
    }
  }

  private clearSafetyTimeout() {
    if (this.safetyTimeout !== null) {
      window.clearTimeout(this.safetyTimeout);
      this.safetyTimeout = null;
    }
  }

  public setLanguage(lang: string) {
    this.lang = lang;
    if (this.recognition) {
      this.recognition.lang = lang;
    }
  }

  public start(callbacks: SpeechRecognitionCallbacks): boolean {
    this.callbacks = callbacks;
    if (!this.recognition) {
      this.init();
    }

    if (!this.recognition) {
      callbacks.onError?.('Speech recognition is not supported in this browser. Please use Chrome on Android or desktop.');
      return false;
    }

    if (this.isListening) {
      try {
        this.recognition.abort();
      } catch {
        // ignore
      }
      this.isListening = false;
    }

    try {
      this.recognition.lang = this.lang;
      this.recognition.start();
      return true;
    } catch (err: any) {
      if (err.name === 'InvalidStateError' || err.message?.includes('already started')) {
        this.isListening = true;
        return true;
      }
      console.error('Error starting speech recognition:', err);
      callbacks.onError?.('Could not start microphone: ' + (err.message || 'Please try again.'));
      this.isListening = false;
      return false;
    }
  }

  public stop() {
    this.clearSafetyTimeout();
    this.isListening = false;
    if (this.recognition) {
      try {
        this.recognition.stop();
      } catch {
        // ignore
      }
    }
  }

  public abort() {
    this.clearSafetyTimeout();
    this.isListening = false;
    if (this.recognition) {
      try {
        this.recognition.abort();
      } catch {
        // ignore
      }
    }
  }

  public getListening(): boolean {
    return this.isListening;
  }
}
