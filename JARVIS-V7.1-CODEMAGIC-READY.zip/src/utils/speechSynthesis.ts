/**
 * Speech Synthesis helper for JARVIS V5
 */

export function cleanTextForSpeech(text: string): string {
  if (!text) return '';
  return text
    // Remove markdown code blocks
    .replace(/```[\s\S]*?```/g, 'Code block omitted.')
    // Remove inline code
    .replace(/`([^`]+)`/g, '$1')
    // Remove markdown links [title](url) -> title
    .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
    // Remove bold/italics markers
    .replace(/[*_~]{1,3}/g, '')
    // Remove headers (# Title)
    .replace(/^#{1,6}\s+/gm, '')
    // Remove markdown bullet points
    .replace(/^\s*[-*+]\s+/gm, '')
    // Remove URLs
    .replace(/https?:\/\/\S+/g, '')
    // Clean excessive whitespaces or newlines
    .replace(/\s+/g, ' ')
    .trim();
}

export function deduplicateVoices(voices: SpeechSynthesisVoice[]): SpeechSynthesisVoice[] {
  if (!voices || voices.length === 0) return [];
  const seen = new Set<string>();
  const unique: SpeechSynthesisVoice[] = [];
  for (const v of voices) {
    const nameKey = (v.name || '').trim().toLowerCase();
    const uriKey = (v.voiceURI || '').trim().toLowerCase();
    const key = uriKey || nameKey || `${(v.lang || '').toLowerCase()}`;
    if (!seen.has(key)) {
      seen.add(key);
      unique.push(v);
    }
  }
  return unique;
}

export function getAvailableVoices(): Promise<SpeechSynthesisVoice[]> {
  return new Promise((resolve) => {
    if (!('speechSynthesis' in window)) {
      resolve([]);
      return;
    }

    const voices = window.speechSynthesis.getVoices();
    if (voices.length > 0) {
      resolve(deduplicateVoices(voices));
      return;
    }

    const handler = () => {
      const updated = window.speechSynthesis.getVoices();
      window.speechSynthesis.removeEventListener('voiceschanged', handler);
      resolve(deduplicateVoices(updated));
    };
    window.speechSynthesis.addEventListener('voiceschanged', handler);

    // Fallback if event doesn't fire
    setTimeout(() => {
      resolve(deduplicateVoices(window.speechSynthesis.getVoices()));
    }, 500);
  });
}

export function findBestVoice(
  voices: SpeechSynthesisVoice[],
  preferredURI?: string,
  preferredLang?: string
): SpeechSynthesisVoice | undefined {
  if (!voices || voices.length === 0) return undefined;

  if (preferredURI) {
    const matched = voices.find((v) => v.voiceURI === preferredURI);
    if (matched) return matched;
  }

  // If Hindi requested or preferred
  if (preferredLang === 'hi-IN' || preferredLang?.startsWith('hi')) {
    const hiVoice = voices.find((v) => v.lang.startsWith('hi'));
    if (hiVoice) return hiVoice;
  }

  // Look for Indian English (en-IN)
  const enInVoice = voices.find((v) => v.lang === 'en-IN' || v.lang.startsWith('en-IN'));
  if (enInVoice) return enInVoice;

  // Fallback to any English voice or default voice
  const defaultVoice = voices.find((v) => v.default);
  if (defaultVoice) return defaultVoice;

  const enVoice = voices.find((v) => v.lang.startsWith('en'));
  if (enVoice) return enVoice;

  return voices[0];
}

export interface SpeakOptions {
  rate?: number;
  pitch?: number;
  voiceURI?: string;
  lang?: string;
  onStart?: () => void;
  onEnd?: () => void;
  onError?: (err: any) => void;
}

export function speakText(text: string, options: SpeakOptions = {}): SpeechSynthesisUtterance | null {
  if (!('speechSynthesis' in window)) {
    console.warn('Speech synthesis not supported');
    options.onError?.(new Error('Speech synthesis not supported on this device/browser'));
    return null;
  }

  // Stop any ongoing speech
  stopSpeaking();

  const clean = cleanTextForSpeech(text);
  if (!clean) return null;

  const utterance = new SpeechSynthesisUtterance(clean);
  utterance.rate = options.rate ?? 1.0;
  utterance.pitch = options.pitch ?? 1.0;

  const voices = window.speechSynthesis.getVoices();
  const selectedVoice = findBestVoice(voices, options.voiceURI, options.lang);
  if (selectedVoice) {
    utterance.voice = selectedVoice;
    utterance.lang = selectedVoice.lang;
  } else if (options.lang) {
    utterance.lang = options.lang;
  }

  utterance.onstart = () => {
    options.onStart?.();
  };

  utterance.onend = () => {
    options.onEnd?.();
  };

  utterance.onerror = (e) => {
    console.warn('Speech synthesis utterance error:', e);
    options.onError?.(e);
  };

  try {
    window.speechSynthesis.speak(utterance);
    return utterance;
  } catch (err) {
    console.error('Failed to trigger window.speechSynthesis.speak:', err);
    options.onError?.(err);
    return null;
  }
}

export function stopSpeaking(): void {
  if ('speechSynthesis' in window) {
    try {
      window.speechSynthesis.cancel();
    } catch {
      // ignore
    }
  }
}

/**
 * Queue that receives chunks of text during AI streaming,
 * extracts full sentences as they arrive, and speaks them sequentially.
 */
export class StreamingSpeechQueue {
  private buffer: string = '';
  private queue: string[] = [];
  private isSpeaking: boolean = false;
  private isStreamDone: boolean = false;
  private options: SpeakOptions;
  private onAllFinished?: () => void;

  constructor(options: SpeakOptions, onAllFinished?: () => void) {
    this.options = options;
    this.onAllFinished = onAllFinished;
    stopSpeaking();
  }

  public pushChunk(chunk: string) {
    this.buffer += chunk;

    // Sentence boundary regex (handles Hindi purna viram ।, question marks, exclamation, periods, newlines)
    const sentenceDelimiters = /([.?!।\n]+[\s]*)/g;
    let match: RegExpExecArray | null;
    let lastIndex = 0;

    while ((match = sentenceDelimiters.exec(this.buffer)) !== null) {
      const sentence = this.buffer.slice(lastIndex, match.index + match[0].length).trim();
      if (sentence.length > 2) {
        this.queue.push(sentence);
      }
      lastIndex = match.index + match[0].length;
    }

    if (lastIndex > 0) {
      this.buffer = this.buffer.slice(lastIndex);
      this.processQueue();
    }
  }

  public finishStream() {
    this.isStreamDone = true;
    if (this.buffer.trim().length > 0) {
      this.queue.push(this.buffer.trim());
      this.buffer = '';
    }
    this.processQueue();
  }

  private processQueue() {
    if (this.isSpeaking || !('speechSynthesis' in window)) return;
    if (this.queue.length === 0) {
      if (this.isStreamDone) {
        this.onAllFinished?.();
      }
      return;
    }

    const nextSentence = this.queue.shift();
    if (!nextSentence) {
      this.processQueue();
      return;
    }

    const clean = cleanTextForSpeech(nextSentence);
    if (!clean) {
      this.processQueue();
      return;
    }

    this.isSpeaking = true;
    const utterance = new SpeechSynthesisUtterance(clean);
    utterance.rate = this.options.rate ?? 1.0;
    utterance.pitch = this.options.pitch ?? 1.0;

    const voices = window.speechSynthesis.getVoices();
    const selectedVoice = findBestVoice(voices, this.options.voiceURI, this.options.lang);
    if (selectedVoice) {
      utterance.voice = selectedVoice;
      utterance.lang = selectedVoice.lang;
    } else if (this.options.lang) {
      utterance.lang = this.options.lang;
    }

    utterance.onstart = () => {
      this.options.onStart?.();
    };

    utterance.onend = () => {
      this.isSpeaking = false;
      this.processQueue();
    };

    utterance.onerror = (e) => {
      console.warn('Streaming utterance error:', e);
      this.isSpeaking = false;
      this.processQueue();
    };

    try {
      window.speechSynthesis.speak(utterance);
    } catch (err) {
      this.isSpeaking = false;
      this.processQueue();
    }
  }

  public stop() {
    this.queue = [];
    this.buffer = '';
    this.isStreamDone = true;
    this.isSpeaking = false;
    stopSpeaking();
  }
}

