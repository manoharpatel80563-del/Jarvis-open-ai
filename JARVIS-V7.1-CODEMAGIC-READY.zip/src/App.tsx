import React, { useState, useEffect, useRef, useCallback } from 'react';
import { AssistantState, ChatMessage, AppSettings, BatteryInfo, NetworkInfo } from './types';
import { JarvisSpeechRecognizer } from './utils/speechRecognition';
import { speakText, stopSpeaking, getAvailableVoices, StreamingSpeechQueue } from './utils/speechSynthesis';
import { checkAndExecuteSmartCommand, parseWakePhrase, isStopCommand } from './utils/smartCommands';
import { Header } from './components/Header';
import { ArcReactor } from './components/ArcReactor';
import { QuickActions } from './components/QuickActions';
import { ResponseCard } from './components/ResponseCard';
import { ConversationHistory } from './components/ConversationHistory';
import { CommandInput } from './components/CommandInput';
import { SettingsModal } from './components/SettingsModal';
import { HelpModal } from './components/HelpModal';
import { DialerModal } from './components/DialerModal';
import { ApkDownloadModal } from './components/ApkDownloadModal';

const DEFAULT_SETTINGS: AppSettings = {
  sttLanguage: 'hi-IN',
  autoSpeak: true,
  speechRate: 1.0,
  speechPitch: 1.0,
  voiceURI: '',
  enableSearchGrounding: false,
  hapticFeedback: true,
  wakeWordEnabled: true,
  wakeWordSensitivity: 3,
  offlineOnlyMode: false,
  enableStreaming: true,
  apiEndpoint: 'https://jarvis-v5.ai.studio',
  aiModel: 'auto',
};

function playWakeChime() {
  try {
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(587.33, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.1);
    gain.gain.setValueAtTime(0.2, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.22);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.22);
  } catch {
    // AudioContext blocked before interaction
  }
}

export default function App() {
  const [assistantState, setAssistantState] = useState<AssistantState>('idle');
  const [transcript, setTranscript] = useState<string>('');
  const [isInterim, setIsInterim] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [continuousMode, setContinuousMode] = useState<boolean>(false);

  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    return [
      {
        id: 'welcome-msg',
        role: 'model',
        text: 'नमस्ते! मैं JARVIS V7 हूँ — आपका AI वॉइस असिस्टेंट।\n\nआप मुझसे हिन्दी, Hinglish, या English में बात कर सकते हैं। ऑफलाइन कमांड्स (Flashlight, Volume, Apps, Dialer) हमेशा तैयार हैं। निरंतर बातचीत के लिए "Continuous Conversation" ऑन करें या "Hey Jarvis" बोलें।',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ];
  });

  const [latestMessage, setLatestMessage] = useState<ChatMessage | null>(() => messages[0]);

  // Telemetry state
  const [battery, setBattery] = useState<BatteryInfo>({ supported: false, level: 100, charging: false });
  const [network, setNetwork] = useState<NetworkInfo>({ online: true });

  // Settings & Voices
  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const saved = localStorage.getItem('jarvis_v6_settings') || localStorage.getItem('jarvis_v5_settings');
      if (saved) {
        const parsed = JSON.parse(saved);
        return { ...DEFAULT_SETTINGS, ...parsed, apiEndpoint: parsed.apiEndpoint?.trim() || DEFAULT_SETTINGS.apiEndpoint, offlineOnlyMode: false };
      }
    } catch {
      // ignore parsing error
    }
    return DEFAULT_SETTINGS;
  });

  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);

  // Modals
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isHelpOpen, setIsHelpOpen] = useState(false);
  const [isDialerOpen, setIsDialerOpen] = useState(false);
  const [isApkModalOpen, setIsApkModalOpen] = useState(false);
  const [dialerNumber, setDialerNumber] = useState('');

  // Speech recognizer and lifecycle refs
  const recognizerRef = useRef<JarvisSpeechRecognizer | null>(null);
  const currentUtteranceRef = useRef<SpeechSynthesisUtterance | null>(null);
  const isExecutingRef = useRef<boolean>(false);
  const isSpeakingRef = useRef<boolean>(false);
  const continuousModeRef = useRef<boolean>(false);
  const autoRestartTimerRef = useRef<number | null>(null);
  const consecutiveErrorsRef = useRef<number>(0);
  const hasHandledSpeechRef = useRef<boolean>(false);
  const streamingSpeechQueueRef = useRef<StreamingSpeechQueue | null>(null);
  const abortControllerRef = useRef<AbortController | null>(null);
  const nativeWakeInitializedRef = useRef<boolean>(false);

  useEffect(() => {
    continuousModeRef.current = continuousMode;
  }, [continuousMode]);

  const clearAutoRestartTimer = () => {
    if (autoRestartTimerRef.current !== null) {
      window.clearTimeout(autoRestartTimerRef.current);
      autoRestartTimerRef.current = null;
    }
  };

  // Initialize Speech Recognizer & Voices
  useEffect(() => {
    recognizerRef.current = new JarvisSpeechRecognizer(settings.sttLanguage);

    const loadVoices = () => {
      getAvailableVoices().then((voices) => {
        setAvailableVoices(voices);
      });
    };
    loadVoices();

    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.addEventListener('voiceschanged', loadVoices);
    }

    // Monitor Network Online/Offline
    const handleOnline = () => setNetwork({ online: true });
    const handleOffline = () => setNetwork({ online: false });
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Monitor Battery Status
    if (typeof navigator !== 'undefined' && 'getBattery' in navigator) {
      (navigator as any).getBattery().then((batt: any) => {
        const updateBatt = () => {
          setBattery({
            supported: true,
            level: Math.round(batt.level * 100),
            charging: batt.charging,
          });
        };
        updateBatt();
        batt.addEventListener('levelchange', updateBatt);
        batt.addEventListener('chargingchange', updateBatt);
      }).catch(() => {
        // Battery status blocked
      });
    }

    return () => {
      clearAutoRestartTimer();
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.removeEventListener('voiceschanged', loadVoices);
      }
      stopSpeaking();
    };
  }, []);

  // Sync settings changes
  useEffect(() => {
    try {
      localStorage.setItem('jarvis_v6_settings', JSON.stringify(settings));
    } catch {
      // ignore
    }
    if (recognizerRef.current) {
      recognizerRef.current.setLanguage(settings.sttLanguage);
    }
  }, [settings]);

  // Start microphone listening session
  const startListening = useCallback(() => {
    clearAutoRestartTimer();

    // CRITICAL: Never start listening while vocalizing (Jarvis must never hear itself) or processing
    if (isSpeakingRef.current || isExecutingRef.current) {
      return;
    }

    setAssistantState('listening');
    setTranscript('');
    setIsInterim(false);
    hasHandledSpeechRef.current = false;

    const started = recognizerRef.current?.start({
      onStart: () => {
        consecutiveErrorsRef.current = 0;
        setAssistantState('listening');
      },
      onTranscript: (payload) => {
        setTranscript(payload.transcript);
        setIsInterim(!payload.isFinal);

        if (payload.isFinal && !hasHandledSpeechRef.current) {
          hasHandledSpeechRef.current = true;
          // Temporarily stop recognition so user speech is not duplicated
          if (recognizerRef.current) {
            recognizerRef.current.stop();
          }
          setAssistantState('processing');
          executeCommand(payload.transcript, true);
        }
      },
      onError: (err) => {
        console.warn('Speech recognizer error:', err);
        isSpeakingRef.current = false;

        // Certain benign errors (no-speech) should silently restart if continuous mode is active
        if (err.error === 'no-speech') {
          if (continuousModeRef.current) {
            setAssistantState('restarting');
            clearAutoRestartTimer();
            autoRestartTimerRef.current = window.setTimeout(() => {
              if (continuousModeRef.current && !isSpeakingRef.current && !isExecutingRef.current) {
                startListening();
              }
            }, 300);
          } else {
            setAssistantState('idle');
          }
          return;
        }

        // Real error handling with consecutive error counter
        consecutiveErrorsRef.current += 1;
        setErrorMessage(`माइक स्थिति: ${err.message || err.error}`);

        if (consecutiveErrorsRef.current >= 3) {
          // Too many rapid errors; pause continuous mode to prevent spinning
          setContinuousMode(false);
          continuousModeRef.current = false;
          setAssistantState('idle');
        } else if (continuousModeRef.current) {
          setAssistantState('restarting');
          clearAutoRestartTimer();
          autoRestartTimerRef.current = window.setTimeout(() => {
            if (continuousModeRef.current && !isSpeakingRef.current && !isExecutingRef.current) {
              startListening();
            }
          }, 800);
        } else {
          setAssistantState('idle');
        }
      },
      onEnd: () => {
        // Recognition ended
        if (!hasHandledSpeechRef.current && !isSpeakingRef.current && !isExecutingRef.current) {
          if (continuousModeRef.current) {
            setAssistantState('restarting');
            clearAutoRestartTimer();
            autoRestartTimerRef.current = window.setTimeout(() => {
              if (continuousModeRef.current && !isSpeakingRef.current && !isExecutingRef.current) {
                startListening();
              }
            }, 300);
          } else {
            setAssistantState('idle');
          }
        }
      },
    });

    if (!started) {
      setAssistantState('idle');
    }
  }, []);

  // Vocalize speech (Text to Speech) with automatic speech recognizer pause
  const handleVocalize = useCallback((text: string, shouldAutoListenAfter = true) => {
    if (!text || !text.trim()) return;

    // Stop active recognition so Jarvis never transcribes its own audio
    if (recognizerRef.current) {
      recognizerRef.current.stop();
    }
    clearAutoRestartTimer();

    if (typeof window !== 'undefined' && window.AndroidBridge?.onAssistantSpeaking) {
      window.AndroidBridge.onAssistantSpeaking(true);
    }

    if (!settings.autoSpeak) {
      isSpeakingRef.current = false;
      if (typeof window !== 'undefined' && window.AndroidBridge?.onAssistantSpeaking) {
        window.AndroidBridge.onAssistantSpeaking(false);
      }
      if (continuousModeRef.current && shouldAutoListenAfter) {
        setAssistantState('restarting');
        clearAutoRestartTimer();
        autoRestartTimerRef.current = window.setTimeout(() => {
          if (continuousModeRef.current && !isSpeakingRef.current && !isExecutingRef.current) {
            startListening();
          }
        }, 300);
      } else {
        setAssistantState('idle');
      }
      return;
    }

    isSpeakingRef.current = true;
    setAssistantState('speaking');

    const utt = speakText(text, {
      rate: settings.speechRate,
      pitch: settings.speechPitch,
      voiceURI: settings.voiceURI,
      lang: settings.sttLanguage,
      onStart: () => {
        isSpeakingRef.current = true;
        setAssistantState('speaking');
        if (typeof window !== 'undefined' && window.AndroidBridge?.onAssistantSpeaking) {
          window.AndroidBridge.onAssistantSpeaking(true);
        }
      },
      onEnd: () => {
        isSpeakingRef.current = false;
        if (typeof window !== 'undefined' && window.AndroidBridge?.onAssistantSpeaking) {
          window.AndroidBridge.onAssistantSpeaking(false);
        }
        if (continuousModeRef.current && shouldAutoListenAfter) {
          setAssistantState('restarting');
          clearAutoRestartTimer();
          autoRestartTimerRef.current = window.setTimeout(() => {
            if (continuousModeRef.current && !isSpeakingRef.current && !isExecutingRef.current) {
              startListening();
            }
          }, 250);
        } else {
          setAssistantState('idle');
        }
      },
      onError: () => {
        isSpeakingRef.current = false;
        if (typeof window !== 'undefined' && window.AndroidBridge?.onAssistantSpeaking) {
          window.AndroidBridge.onAssistantSpeaking(false);
        }
        if (continuousModeRef.current && shouldAutoListenAfter) {
          setAssistantState('restarting');
          clearAutoRestartTimer();
          autoRestartTimerRef.current = window.setTimeout(() => {
            if (continuousModeRef.current && !isSpeakingRef.current && !isExecutingRef.current) {
              startListening();
            }
          }, 250);
        } else {
          setAssistantState('idle');
        }
      },
    });
    currentUtteranceRef.current = utt;
  }, [settings, startListening]);

  // Stop vocal speech immediately
  const handleStopSpeech = useCallback(() => {
    if (streamingSpeechQueueRef.current) {
      streamingSpeechQueueRef.current.stop();
      streamingSpeechQueueRef.current = null;
    }
    stopSpeaking();
    isSpeakingRef.current = false;
    if (typeof window !== 'undefined' && window.AndroidBridge?.onAssistantSpeaking) {
      window.AndroidBridge.onAssistantSpeaking(false);
    }
    if (continuousModeRef.current) {
      setAssistantState('restarting');
      clearAutoRestartTimer();
      autoRestartTimerRef.current = window.setTimeout(() => {
        if (continuousModeRef.current && !isSpeakingRef.current && !isExecutingRef.current) {
          startListening();
        }
      }, 200);
    } else {
      setAssistantState('idle');
    }
  }, [startListening]);

  // Core Command Execution Engine
  const executeCommand = useCallback(async (commandText: string, isVoice = false) => {
    const raw = commandText.trim();
    if (!raw) return;

    if (isExecutingRef.current) {
      console.log('Skipping duplicate command execution while another is in progress:', raw);
      return;
    }
    isExecutingRef.current = true;

    // Abort any ongoing stream
    if (abortControllerRef.current) {
      try {
        abortControllerRef.current.abort();
      } catch {}
      abortControllerRef.current = null;
    }

    // Stop speaking if currently vocalizing
    handleStopSpeech();
    clearAutoRestartTimer();
    setErrorMessage('');
    setAssistantState('processing');

    const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    // Add user message to state
    const userMsg: ChatMessage = {
      id: `user-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      role: 'user',
      text: raw,
      timestamp,
      isVoiceInput: isVoice,
    };

    setMessages((prev) => [...prev, userMsg]);

    try {
      const wake = parseWakePhrase(raw);

      // 1. STOP COMMAND CHECK: "Stop Jarvis", "Band ho jao", "Bas Jarvis", "Stop listening", "सुनना बंद करो", "जार्विस बंद हो जाओ"
      const isStop = isStopCommand(raw) || (wake.hasWakePhrase && isStopCommand(wake.cleanedText));
      if (isStop) {
        if (recognizerRef.current) {
          recognizerRef.current.stop();
        }
        setContinuousMode(false);
        continuousModeRef.current = false;
        handleStopSpeech();
        setAssistantState('idle');

        const stopReplies = [
          'Standby mode mein jaa raha hoon. Jab bhi zaroorat ho, "Hey Jarvis" bolein.',
          'Theek hai sir, main standby par hoon.',
          'Stopped. JARVIS is on standby.',
          'सुनना बंद कर दिया है। जब जरूरत हो बुलाएं।',
        ];
        const stopReply = stopReplies[Math.floor(Math.random() * stopReplies.length)];

        const stopMsg: ChatMessage = {
          id: `model-stop-${Date.now()}`,
          role: 'model',
          text: `🛑 **JARVIS Standby Active**\n\n${stopReply}`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
        setMessages((prev) => [...prev, stopMsg]);
        setLatestMessage(stopMsg);

        handleVocalize(stopReply, false);
        return;
      }

      // 2. WAKE PHRASE ONLY CHECK (User just said "Hey Jarvis" or "जार्विस")
      if (wake.hasWakePhrase && wake.isWakeOnly) {
        playWakeChime();
        setContinuousMode(true);
        continuousModeRef.current = true;

        const wakeGreetings = [
          'Yes sir, I am listening. Kaise madad kar sakta hoon?',
          'Ji sir, bolein, main sun raha hoon.',
          'At your service, sir. What can I do for you?',
          'नमस्ते! आज्ञा दीजिए, क्या सहायता करूँ?',
        ];
        const wakeReplySpoken = wakeGreetings[Math.floor(Math.random() * wakeGreetings.length)];

        const modelMsg: ChatMessage = {
          id: `model-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
          role: 'model',
          text: `⚡ **JARVIS Online**\n\n${wakeReplySpoken}`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };

        setMessages((prev) => [...prev, modelMsg]);
        setLatestMessage(modelMsg);

        // Auto-listen after answering wake phrase
        handleVocalize(wakeReplySpoken, true);
        return;
      }

      // Determine the effective query (strip wake phrase if present)
      const effectiveQuery = wake.hasWakePhrase && wake.cleanedText ? wake.cleanedText : raw;

      // 3. CHECK LOCAL SMART COMMANDS (Math, Time, Date, Battery, Network, Apps, Torch, Call)
      const smartResult = await checkAndExecuteSmartCommand(effectiveQuery);

      if (smartResult && smartResult.handled) {
        const modelMsg: ChatMessage = {
          id: `model-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
          role: 'model',
          text: smartResult.displayText,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          actionTaken: smartResult.actionLabel,
          actionUrl: smartResult.actionUrl,
        };

        setMessages((prev) => [...prev, modelMsg]);
        setLatestMessage(modelMsg);

        if (smartResult.actionType === 'help') {
          setIsHelpOpen(true);
        } else if (smartResult.actionType === 'dialer' && smartResult.metadata?.number) {
          setDialerNumber(smartResult.metadata.number);
        } else if (smartResult.actionType === 'stop') {
          setContinuousMode(false);
          continuousModeRef.current = false;
          handleVocalize(smartResult.spokenReply, false);
          return;
        }

        // Vocalize response and continue conversation loop
        handleVocalize(smartResult.spokenReply, true);
        return;
      }

      // 4. CHECK IF STRICT OFFLINE MODE IS REQUESTED
      if (settings.offlineOnlyMode) {
        const offlineReply = 'Offline mode active. Flashlight, volume, apps aur dialer offline taiyar hain.';
        const offlineMsg: ChatMessage = {
          id: `model-offline-${Date.now()}`,
          role: 'model',
          text: `ℹ️ **Offline Mode Active**: Flashlight, Volume, Apps, Dialer, Battery, Time aur Math offline taiyar hain.\n\n*General AI conversation ke liye Settings se Online Mode on karein.*`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
        setMessages((prev) => [...prev, offlineMsg]);
        setLatestMessage(offlineMsg);
        handleVocalize(offlineReply, true);
        return;
      }

      // 5. CHECK NETWORK STATUS BEFORE ROUTING TO ONLINE AI
      const isOffline = typeof navigator !== 'undefined' && navigator.onLine === false;
      const isFileProtocol = typeof window !== 'undefined' && window.location.protocol === 'file:';
      const customEndpoint = settings.apiEndpoint?.trim();

      if (isOffline) {
        const offlineReply = 'Online AI unavailable, offline mode active.';
        const offlineMsg: ChatMessage = {
          id: `model-offline-${Date.now()}`,
          role: 'model',
          text: `⚠️ **Online AI unavailable, offline mode active.**\n\nFlashlight, volume, apps, dialer, battery aur math offline bilkul theek chal rahe hain.`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
        setMessages((prev) => [...prev, offlineMsg]);
        setLatestMessage(offlineMsg);
        handleVocalize(offlineReply, true);
        return;
      }

      // Pass clean history (last 10 turns) so follow-ups work accurately
      const cleanHistory = messages
        .filter((m) => !m.isError)
        .slice(-10)
        .map((m) => ({
          role: m.role === 'model' ? 'model' : 'user',
          text: m.text.replace(/\*\*[^*]+\*\*:?/g, '').trim(),
        }));

      // 6. ONLINE AI BRAIN WITH FAST STREAMING & FALLBACK
      const useStreaming = settings.enableStreaming !== false && typeof ReadableStream !== 'undefined';
      let streamingSuccess = false;

      if (useStreaming) {
        let streamUrl = '/api/chat/stream';
        if (customEndpoint) {
          const cleanBase = customEndpoint.replace(/\/api\/(chat|health)(\/stream)?$/, '').replace(/\/$/, '');
          streamUrl = `${cleanBase}/api/chat/stream`;
        }

        const controller = new AbortController();
        abortControllerRef.current = controller;

        const modelMsgId = `model-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
        let accumulatedReply = '';
        let streamedSources: any[] = [];

        // Setup streaming speech queue if voice response is enabled
        if (settings.autoSpeak) {
          streamingSpeechQueueRef.current = new StreamingSpeechQueue(
            {
              rate: settings.speechRate,
              pitch: settings.speechPitch,
              voiceURI: settings.voiceURI,
              lang: settings.sttLanguage,
              onStart: () => {
                isSpeakingRef.current = true;
                setAssistantState('speaking');
                if (typeof window !== 'undefined' && window.AndroidBridge?.onAssistantSpeaking) {
                  window.AndroidBridge.onAssistantSpeaking(true);
                }
              },
            },
            () => {
              isSpeakingRef.current = false;
              if (typeof window !== 'undefined' && window.AndroidBridge?.onAssistantSpeaking) {
                window.AndroidBridge.onAssistantSpeaking(false);
              }
              if (continuousModeRef.current) {
                setAssistantState('restarting');
                clearAutoRestartTimer();
                autoRestartTimerRef.current = window.setTimeout(() => {
                  if (continuousModeRef.current && !isSpeakingRef.current && !isExecutingRef.current) {
                    startListening();
                  }
                }, 250);
              } else {
                setAssistantState('idle');
              }
            }
          );
        }

        try {
          const res = await fetch(streamUrl, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Accept: 'text/event-stream',
            },
            body: JSON.stringify({
              message: effectiveQuery,
              history: cleanHistory,
              enableSearch: settings.enableSearchGrounding,
              preferredModel: settings.aiModel || 'auto',
            }),
            signal: controller.signal,
          });

          if (res.ok && res.body) {
            streamingSuccess = true;
            const reader = res.body.getReader();
            const decoder = new TextDecoder('utf-8');
            let buffer = '';

            // Add empty message placeholder
            const initialModelMsg: ChatMessage = {
              id: modelMsgId,
              role: 'model',
              text: 'Thinking...',
              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            };
            setMessages((prev) => [...prev, initialModelMsg]);

            while (true) {
              const { value, done } = await reader.read();
              if (done) break;

              buffer += decoder.decode(value, { stream: true });
              const lines = buffer.split('\n');
              buffer = lines.pop() || '';

              for (const line of lines) {
                const trimmed = line.trim();
                if (trimmed.startsWith('data:')) {
                  const jsonStr = trimmed.slice(5).trim();
                  if (!jsonStr) continue;
                  if (jsonStr === '[DONE]') {
                    break;
                  }
                  try {
                    const eventData = JSON.parse(jsonStr);
                    const piece = eventData.chunk || eventData.text;
                    if (piece) {
                      accumulatedReply += piece;
                      if (settings.autoSpeak && streamingSpeechQueueRef.current) {
                        streamingSpeechQueueRef.current.pushChunk(piece);
                      }
                      setMessages((prev) =>
                        prev.map((m) => (m.id === modelMsgId ? { ...m, text: accumulatedReply } : m))
                      );
                      setLatestMessage((curr) =>
                        curr && curr.id === modelMsgId ? { ...curr, text: accumulatedReply } : curr
                      );
                    }
                    if (eventData.sources) {
                      streamedSources = eventData.sources;
                    }
                    if (eventData.done) {
                      break;
                    }
                  } catch {
                    // Ignore non-json lines
                  }
                }
              }
            }

            if (settings.autoSpeak && streamingSpeechQueueRef.current) {
              streamingSpeechQueueRef.current.finishStream();
            } else if (!settings.autoSpeak) {
              setAssistantState('idle');
              if (continuousModeRef.current) {
                setAssistantState('restarting');
                autoRestartTimerRef.current = window.setTimeout(() => {
                  if (continuousModeRef.current && !isSpeakingRef.current && !isExecutingRef.current) {
                    startListening();
                  }
                }, 300);
              }
            }

            const finalText = accumulatedReply || 'JARVIS responded.';
            const finalMsg: ChatMessage = {
              id: modelMsgId,
              role: 'model',
              text: finalText,
              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              sources: streamedSources,
            };

            setMessages((prev) => prev.map((m) => (m.id === modelMsgId ? finalMsg : m)));
            setLatestMessage(finalMsg);
            return;
          }
        } catch (streamErr: any) {
          if (streamErr?.name === 'AbortError') {
            console.log('Streaming aborted by new user command');
            return;
          }
          console.warn('Streaming failed, attempting standard JSON API fallback:', streamErr?.message);
        }
      }

      // Fallback: Standard /api/chat endpoint
      let apiUrl = '/api/chat';
      if (customEndpoint) {
        const cleanBase = customEndpoint.replace(/\/api\/(chat|health)(\/stream)?$/, '').replace(/\/$/, '');
        apiUrl = `${cleanBase}/api/chat`;
      }

      let reply = '';
      let sources = [];
      try {
        const res = await fetch(apiUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            message: effectiveQuery,
            history: cleanHistory,
            enableSearch: settings.enableSearchGrounding,
            preferredModel: settings.aiModel || 'auto',
          }),
        });

        if (!res.ok) {
          const errJson = await res.json().catch(() => ({}));
          throw new Error(errJson.error || errJson.details || `Server response: ${res.status}`);
        }

        const data = await res.json();
        reply = data.reply || 'JARVIS online.';
        sources = data.sources || [];
      } catch (fetchErr: any) {
        if (isFileProtocol && !customEndpoint) {
          const localNoticeText = `ℹ️ **स्थानीय मोड सक्रिय**: डिवाइस नियंत्रण (Flashlight, Volume, Dialer, WhatsApp, Camera) और ऑफलाइन टूल्स काम कर रहे हैं।`;
          const modelNotice: ChatMessage = {
            id: `model-notice-${Date.now()}`,
            role: 'model',
            text: localNoticeText,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          };
          setMessages((prev) => [...prev, modelNotice]);
          setLatestMessage(modelNotice);
          handleVocalize('Online AI unavailable, offline mode active.', true);
          return;
        }
        throw fetchErr;
      }

      const modelMsg: ChatMessage = {
        id: `model-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        role: 'model',
        text: reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        sources: sources,
      };

      setMessages((prev) => [...prev, modelMsg]);
      setLatestMessage(modelMsg);

      // Vocalize AI response and continue loop
      handleVocalize(reply, true);
    } catch (err: any) {
      console.error('Technical error in JARVIS core:', err);
      const friendlyError = 'Online AI unavailable, offline mode active.';
      setErrorMessage(friendlyError);

      const errorModelMsg: ChatMessage = {
        id: `model-err-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        role: 'model',
        text: `⚠️ **सिस्टम सूचना**: ${friendlyError}\n\n*ऑफलाइन टूल्स (फ्लैशलाइट, वॉल्यूम, ऐप्स, डायलर, बैटरी) तैयार हैं।*`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isError: true,
      };

      setMessages((prev) => [...prev, errorModelMsg]);
      setLatestMessage(errorModelMsg);

      // Vocalize error and maintain continuous listening loop
      handleVocalize(friendlyError, true);
    } finally {
      isExecutingRef.current = false;
    }
  }, [messages, settings, handleVocalize, handleStopSpeech, startListening]);

  // Native Android Bridge Listeners & Synchronization
  useEffect(() => {
    if (typeof window === 'undefined') return;

    // 1. Register native wake word handler (from WakeWordService)
    window.onJarvisNativeWakeWordDetected = () => {
      console.log('[NativeBridge] Hey Jarvis wake word detected by native service');
      if (window.AndroidBridge?.vibrate) {
        window.AndroidBridge.vibrate(60);
      }
      playWakeChime();
      setContinuousMode(true);
      continuousModeRef.current = true;
      if (!isSpeakingRef.current && !isExecutingRef.current) {
        startListening();
      }
    };

    // 2. Register native voice command handler
    window.onJarvisNativeVoiceCommand = (cmd: string) => {
      if (cmd && cmd.trim()) {
        console.log('[NativeBridge] Native voice command received:', cmd);
        executeCommand(cmd.trim(), true);
      }
    };

    // 3. Initialize native wake word setting once on mount
    if (!nativeWakeInitializedRef.current && window.AndroidBridge?.setWakeWordEnabled) {
      nativeWakeInitializedRef.current = true;
      window.AndroidBridge.setWakeWordEnabled(settings.wakeWordEnabled ?? true);
    }

    // 4. Query native battery state
    if (window.AndroidBridge?.getBatteryLevel) {
      const lvl = window.AndroidBridge.getBatteryLevel();
      const charging = window.AndroidBridge.isBatteryCharging ? window.AndroidBridge.isBatteryCharging() : false;
      if (lvl >= 0) {
        setBattery({ supported: true, level: lvl, charging });
      }
    }

    return () => {
      if (typeof window !== 'undefined') {
        window.onJarvisNativeWakeWordDetected = undefined;
        window.onJarvisNativeVoiceCommand = undefined;
      }
    };
  }, [executeCommand, startListening]);

  // Wake Word persistent state toggle
  const handleToggleWakeWord = useCallback(() => {
    setSettings((prev) => {
      const nextEnabled = !prev.wakeWordEnabled;
      const updated = { ...prev, wakeWordEnabled: nextEnabled };
      try {
        localStorage.setItem('jarvis_v6_settings', JSON.stringify(updated));
      } catch {}
      if (typeof window !== 'undefined' && window.AndroidBridge?.setWakeWordEnabled) {
        window.AndroidBridge.setWakeWordEnabled(nextEnabled);
      }
      return updated;
    });
  }, []);

  // Toggle Continuous Conversation Mode
  const handleToggleContinuousMode = useCallback(() => {
    if (continuousMode) {
      // Disable continuous mode
      setContinuousMode(false);
      continuousModeRef.current = false;
      clearAutoRestartTimer();
      if (recognizerRef.current) {
        recognizerRef.current.stop();
      }
      setAssistantState('idle');
    } else {
      // Enable continuous mode
      setContinuousMode(true);
      continuousModeRef.current = true;
      setErrorMessage('');
      if (!isSpeakingRef.current && !isExecutingRef.current) {
        startListening();
      }
    }
  }, [continuousMode, startListening]);

  // Toggle Microphone manually
  const handleMicClick = useCallback(() => {
    // If currently speaking, stop speech first
    if (assistantState === 'speaking') {
      handleStopSpeech();
      return;
    }

    // If currently listening, stop recognition
    if (assistantState === 'listening') {
      clearAutoRestartTimer();
      if (recognizerRef.current) {
        recognizerRef.current.stop();
      }
      setAssistantState('idle');
      return;
    }

    // Start recognition
    startListening();
  }, [assistantState, handleStopSpeech, startListening]);

  // Initiate call via phone dialer
  const handleInitiateCall = (number: string) => {
    const cleanNum = number.replace(/\s+/g, '');
    const telLink = `tel:${cleanNum}`;
    executeCommand(`Call ${cleanNum}`, false);
    window.location.href = telLink;
  };

  return (
    <div className="min-h-screen bg-gray-950 text-cyan-50 font-sans flex flex-col justify-between selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* Background Sci-Fi Grid and Glows */}
      <div className="fixed inset-0 pointer-events-none opacity-20 bg-[radial-gradient(#0891b2_1px,transparent_1px)] [background-size:24px_24px]" />
      <div className="fixed -top-40 left-1/2 -translate-x-1/2 w-[500px] h-[500px] bg-cyan-600/10 rounded-full blur-[120px] pointer-events-none" />

      {/* Top Header */}
      <Header
        network={network}
        battery={battery}
        autoSpeak={settings.autoSpeak}
        onToggleAutoSpeak={() => setSettings((s) => ({ ...s, autoSpeak: !s.autoSpeak }))}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenHelp={() => setIsHelpOpen(true)}
        onOpenApkModal={() => setIsApkModalOpen(true)}
        isOfflineMode={settings.offlineOnlyMode}
      />

      {/* Main Interactive Stage */}
      <main className="flex-1 flex flex-col items-center justify-start w-full relative z-10 pb-4">
        {/* Holographic Arc Reactor Core with Microphone */}
        <ArcReactor
          state={assistantState}
          transcript={transcript}
          isInterim={isInterim}
          onMicClick={handleMicClick}
          onStopSpeaking={handleStopSpeech}
          language={settings.sttLanguage}
          errorMessage={errorMessage}
          continuousMode={continuousMode}
          onToggleContinuousMode={handleToggleContinuousMode}
          wakeWordEnabled={settings.wakeWordEnabled ?? true}
          onToggleWakeWord={handleToggleWakeWord}
        />

        {/* Quick Actions Bar */}
        <QuickActions
          onExecuteCommand={(cmd) => executeCommand(cmd, false)}
          onOpenDialer={() => setIsDialerOpen(true)}
          onOpenHelp={() => setIsHelpOpen(true)}
          disabled={assistantState === 'processing'}
        />

        {/* Latest Response HUD */}
        <ResponseCard
          message={latestMessage}
          isSpeaking={assistantState === 'speaking'}
          onReplaySpeech={(text) => handleVocalize(text)}
          onStopSpeech={handleStopSpeech}
        />

        {/* Conversation History Drawer */}
        <ConversationHistory
          messages={messages}
          onClearHistory={() => {
            setMessages([]);
            setLatestMessage(null);
          }}
          onReplaySpeech={(text) => handleVocalize(text)}
        />
      </main>

      {/* Sticky Bottom Text Input Bar */}
      <CommandInput
        onSubmit={(text) => executeCommand(text, false)}
        disabled={assistantState === 'processing'}
        placeholder={
          settings.sttLanguage === 'hi-IN'
            ? 'यहाँ लिखें या माइक दबाकर बोलें (उदा. समय बताओ, WhatsApp खोलो)...'
            : 'Type command or question for JARVIS...'
        }
      />

      {/* Modals */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onUpdateSettings={(newVals) => setSettings((s) => ({ ...s, ...newVals }))}
        onSaveSettings={(saved) => {
          setSettings(saved);
          try {
            localStorage.setItem('jarvis_v6_settings', JSON.stringify(saved));
          } catch {}
          if (typeof window !== 'undefined' && window.AndroidBridge?.setWakeWordEnabled) {
            window.AndroidBridge.setWakeWordEnabled(saved.wakeWordEnabled ?? true);
          }
        }}
        availableVoices={availableVoices}
      />

      <HelpModal
        isOpen={isHelpOpen}
        onClose={() => setIsHelpOpen(false)}
        onTestCommand={(cmd) => executeCommand(cmd, false)}
      />

      <DialerModal
        isOpen={isDialerOpen}
        onClose={() => setIsDialerOpen(false)}
        initialNumber={dialerNumber}
        onInitiateCall={handleInitiateCall}
      />

      <ApkDownloadModal
        isOpen={isApkModalOpen}
        onClose={() => setIsApkModalOpen(false)}
      />
    </div>
  );
}
