import React, { useState } from 'react';
import { X, Phone, PhoneCall, Delete, ShieldAlert } from 'lucide-react';

interface DialerModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialNumber?: string;
  onInitiateCall: (number: string) => void;
}

export const DialerModal: React.FC<DialerModalProps> = ({
  isOpen,
  onClose,
  initialNumber = '',
  onInitiateCall,
}) => {
  const [number, setNumber] = useState(initialNumber);

  if (!isOpen) return null;

  const handleDigit = (digit: string) => {
    if (number.length < 15) {
      setNumber((prev) => prev + digit);
    }
  };

  const handleBackspace = () => {
    setNumber((prev) => prev.slice(0, -1));
  };

  const handleCall = () => {
    if (number.trim()) {
      onInitiateCall(number.trim());
      onClose();
    }
  };

  const dialKeys = [
    { key: '1', sub: '' },
    { key: '2', sub: 'ABC' },
    { key: '3', sub: 'DEF' },
    { key: '4', sub: 'GHI' },
    { key: '5', sub: 'JKL' },
    { key: '6', sub: 'MNO' },
    { key: '7', sub: 'PQRS' },
    { key: '8', sub: 'TUV' },
    { key: '9', sub: 'WXYZ' },
    { key: '*', sub: '' },
    { key: '0', sub: '+' },
    { key: '#', sub: '' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
      <div className="relative w-full max-w-sm rounded-2xl border border-cyan-500/40 bg-gray-950 p-5 text-cyan-50 shadow-[0_0_35px_rgba(6,182,212,0.3)]">
        {/* Close Button */}
        <button
          id="btn-close-dialer"
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full border border-cyan-900 bg-gray-900 text-cyan-400 hover:bg-cyan-900/50"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Title */}
        <div className="flex items-center gap-2 mb-3">
          <Phone className="w-5 h-5 text-cyan-400" />
          <h3 className="text-base font-bold font-['Orbitron'] tracking-wider text-cyan-200">
            PHONE DIALER HUD
          </h3>
        </div>

        {/* Number Screen */}
        <div className="flex items-center justify-between rounded-xl border border-cyan-500/30 bg-gray-900/90 p-3 mb-4">
          <input
            id="input-dialer-number"
            type="tel"
            value={number}
            onChange={(e) => setNumber(e.target.value.replace(/[^0-9+*#]/g, ''))}
            placeholder="Enter phone number..."
            className="w-full bg-transparent text-xl font-mono text-cyan-100 placeholder:text-cyan-800 focus:outline-none tracking-widest text-center"
          />
          {number && (
            <button
              type="button"
              onClick={handleBackspace}
              className="p-1.5 text-cyan-400 hover:text-cyan-200"
            >
              <Delete className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Keypad Grid */}
        <div className="grid grid-cols-3 gap-2.5 mb-4">
          {dialKeys.map((item) => (
            <button
              key={item.key}
              type="button"
              onClick={() => handleDigit(item.key)}
              className="flex flex-col items-center justify-center h-14 rounded-xl border border-cyan-900/60 bg-gray-900/60 hover:bg-cyan-950/50 hover:border-cyan-500/50 active:scale-95 transition-all text-cyan-200"
            >
              <span className="text-lg font-bold font-mono">{item.key}</span>
              {item.sub && <span className="text-[9px] text-cyan-500/70 tracking-widest">{item.sub}</span>}
            </button>
          ))}
        </div>

        {/* Action Button */}
        <div className="flex flex-col gap-2">
          <button
            id="btn-confirm-dial-call"
            type="button"
            disabled={!number.trim()}
            onClick={handleCall}
            className="w-full flex items-center justify-center gap-2 h-12 rounded-xl border border-emerald-400/80 bg-emerald-600/30 hover:bg-emerald-600/50 text-emerald-200 font-mono font-bold text-sm shadow-[0_0_20px_rgba(16,185,129,0.3)] transition-all disabled:opacity-40 disabled:pointer-events-none active:scale-95"
          >
            <PhoneCall className="w-4 h-4 text-emerald-300 animate-pulse" />
            <span>Launch Phone Dialer ({number || '...' })</span>
          </button>

          {/* Browser Limitation Notice */}
          <div className="flex items-start gap-2 p-2.5 rounded-lg border border-amber-500/20 bg-amber-950/20 text-amber-300/80 text-[11px] font-mono leading-tight">
            <ShieldAlert className="w-4 h-4 flex-shrink-0 text-amber-400 mt-0.5" />
            <span>
              <strong>Security Protocol</strong>: Web browsers strictly prevent web apps from automatically answering or connecting calls in the background. Tapping Call opens your phone's native dialer safely.
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
