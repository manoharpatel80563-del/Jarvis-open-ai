import React from 'react';
import { X, Smartphone, Download, CheckCircle2, Shield, FolderArchive, ArrowRight, Radio } from 'lucide-react';

interface ApkDownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ApkDownloadModal: React.FC<ApkDownloadModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in">
      <div className="relative w-full max-w-lg max-h-[90vh] flex flex-col rounded-2xl border border-cyan-500/50 bg-gray-950 p-6 text-cyan-50 shadow-[0_0_50px_rgba(6,182,212,0.35)] font-mono">
        {/* Close Button */}
        <button
          id="btn-close-apk-modal"
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full border border-cyan-900 bg-gray-900 text-cyan-400 hover:bg-cyan-900/50 transition-all"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-3">
          <div className="p-2.5 rounded-xl border border-cyan-500/40 bg-cyan-950/60 text-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.4)]">
            <Smartphone className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-lg font-bold font-['Orbitron'] tracking-wider text-cyan-200">
              JARVIS V7 ANDROID APK
            </h3>
            <span className="text-xs text-cyan-400/80">
              Native Android Package (versionCode: 7 • versionName: 7.0.0)
            </span>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto pr-1 space-y-4 text-xs font-sans">
          {/* Main Download Action Buttons */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            {/* Direct APK Download */}
            <a
              id="btn-download-apk-direct"
              href="/api/download-apk"
              download="jarvis-v7-debug.apk"
              className="flex flex-col items-center justify-center p-4 rounded-xl border-2 border-cyan-400 bg-gradient-to-b from-cyan-950/80 to-cyan-900/40 hover:from-cyan-900/80 hover:to-cyan-800/60 text-cyan-100 shadow-[0_0_25px_rgba(6,182,212,0.4)] transition-all group active:scale-98"
            >
              <Download className="w-7 h-7 text-cyan-300 mb-2 group-hover:scale-110 transition-transform animate-bounce" />
              <span className="font-bold text-sm tracking-wide font-['Orbitron'] text-cyan-200">
                DOWNLOAD APK V7
              </span>
              <span className="text-[11px] font-mono text-cyan-400/90 mt-1">
                jarvis-v7-debug.apk (v7.0.0)
              </span>
              <span className="mt-2 px-2 py-0.5 rounded-full text-[10px] font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                Ready to Install on Phone
              </span>
            </a>

            {/* Android Project ZIP */}
            <a
              id="btn-download-project-zip"
              href="/api/download-project-zip"
              download="jarvis-v7-android-project.zip"
              className="flex flex-col items-center justify-center p-4 rounded-xl border border-cyan-600/50 bg-gray-900/80 hover:bg-cyan-950/40 text-cyan-200 shadow-sm transition-all group active:scale-98"
            >
              <FolderArchive className="w-7 h-7 text-cyan-400 mb-2 group-hover:scale-110 transition-transform" />
              <span className="font-bold text-sm tracking-wide font-['Orbitron'] text-cyan-300">
                PROJECT ZIP
              </span>
              <span className="text-[11px] font-mono text-cyan-400/80 mt-1">
                Full Android Source Code (V7)
              </span>
              <span className="mt-2 px-2 py-0.5 rounded-full text-[10px] font-mono text-cyan-400/80 border border-cyan-900">
                Gradle + Java + CLI Scripts
              </span>
            </a>
          </div>

          {/* Features Included in APK */}
          <div className="p-3.5 rounded-xl border border-cyan-950 bg-gray-900/60 space-y-2">
            <h4 className="text-xs font-bold font-['Orbitron'] text-cyan-300 flex items-center gap-1.5">
              <Radio className="w-3.5 h-3.5 text-cyan-400" />
              NATIVE CAPABILITIES INCLUDED
            </h4>
            <div className="grid grid-cols-2 gap-2 text-[11px] text-cyan-200/90">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                <span>"Hey Jarvis" Wake Word</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                <span>Flashlight / Torch Control</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                <span>Volume & Mute Control</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                <span>WiFi & System Settings</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                <span>App Launcher (WhatsApp, etc.)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                <span>Music / Media Controls</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                <span>Phone Call & Dialer</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                <span>Secure Gemini API Core</span>
              </div>
            </div>
          </div>

          {/* How to Install Guide */}
          <div className="p-3.5 rounded-xl border border-cyan-900/50 bg-cyan-950/30 space-y-2">
            <h4 className="text-xs font-bold text-cyan-300 flex items-center gap-1.5">
              <Shield className="w-3.5 h-3.5 text-amber-400" />
              HOW TO INSTALL ON ANDROID PHONE
            </h4>
            <ol className="space-y-1.5 text-[11px] text-cyan-300/90 list-decimal list-inside">
              <li>
                Tap <strong>DOWNLOAD APK</strong> to download <code className="text-cyan-200">jarvis-v7-debug.apk</code>.
              </li>
              <li>
                Open the downloaded file from Chrome notifications or your phone's <em>Files / Downloads</em> folder.
              </li>
              <li>
                If prompted, toggle <strong>"Allow from this source"</strong> (Standard Android permission for APKs outside Play Store).
              </li>
              <li>
                Tap <strong>Install</strong>, then open <strong>JARVIS AI</strong> and allow Microphone and Camera permissions.
              </li>
            </ol>
          </div>
        </div>
      </div>
    </div>
  );
};
