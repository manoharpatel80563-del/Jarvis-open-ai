import React from 'react';
import { Clock, Calendar, Battery, Wifi, Search, Youtube, MessageCircle, PhoneCall, HelpCircle } from 'lucide-react';

interface QuickActionsProps {
  onExecuteCommand: (commandText: string) => void;
  onOpenDialer: () => void;
  onOpenHelp: () => void;
  disabled?: boolean;
}

export const QuickActions: React.FC<QuickActionsProps> = ({
  onExecuteCommand,
  onOpenDialer,
  onOpenHelp,
  disabled = false,
}) => {
  const actions = [
    {
      id: 'time',
      label: 'समय',
      sub: 'Time',
      icon: Clock,
      command: 'समय बताओ',
      color: 'hover:border-cyan-400 text-cyan-300',
    },
    {
      id: 'date',
      label: 'तारीख',
      sub: 'Date',
      icon: Calendar,
      command: 'आज की तारीख बताओ',
      color: 'hover:border-cyan-400 text-cyan-300',
    },
    {
      id: 'battery',
      label: 'बैटरी',
      sub: 'Battery',
      icon: Battery,
      command: 'battery बताओ',
      color: 'hover:border-emerald-400 text-emerald-300',
    },
    {
      id: 'internet',
      label: 'इंटरनेट',
      sub: 'Online',
      icon: Wifi,
      command: 'internet बताओ',
      color: 'hover:border-sky-400 text-sky-300',
    },
    {
      id: 'google',
      label: 'Google',
      sub: 'Search',
      icon: Search,
      command: 'Google पर search करो',
      color: 'hover:border-blue-400 text-blue-300',
    },
    {
      id: 'youtube',
      label: 'YouTube',
      sub: 'Video',
      icon: Youtube,
      command: 'YouTube खोलो',
      color: 'hover:border-red-400 text-red-400',
    },
    {
      id: 'whatsapp',
      label: 'WhatsApp',
      sub: 'Chat',
      icon: MessageCircle,
      command: 'WhatsApp खोलो',
      color: 'hover:border-green-400 text-green-400',
    },
    {
      id: 'call',
      label: 'Call',
      sub: 'Dialer',
      icon: PhoneCall,
      onClick: onOpenDialer,
      color: 'hover:border-amber-400 text-amber-300',
    },
    {
      id: 'help',
      label: 'मदद',
      sub: 'Help',
      icon: HelpCircle,
      onClick: onOpenHelp,
      color: 'hover:border-violet-400 text-violet-300',
    },
  ];

  return (
    <div className="w-full max-w-xl mx-auto px-4 py-2">
      <div className="flex items-center justify-between mb-2">
        <span className="text-[11px] font-mono uppercase tracking-widest text-cyan-400/80 font-bold">
          ⚡ SMART COMMAND SHORTCUTS
        </span>
        <span className="text-[10px] font-mono text-cyan-500/60">ONE-TOUCH HUD</span>
      </div>

      <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
        {actions.map((act) => {
          const Icon = act.icon;
          return (
            <button
              key={act.id}
              id={`quick-action-${act.id}`}
              type="button"
              disabled={disabled}
              onClick={() => {
                if (act.onClick) {
                  act.onClick();
                } else if (act.command) {
                  onExecuteCommand(act.command);
                }
              }}
              className={`flex flex-col items-center justify-center p-2.5 min-h-[48px] rounded-xl border border-cyan-900/40 bg-gray-900/70 backdrop-blur-sm transition-all active:scale-95 disabled:opacity-50 disabled:pointer-events-none hover:bg-cyan-950/40 ${act.color}`}
            >
              <Icon className="w-4 h-4 mb-1" />
              <div className="flex items-baseline gap-1">
                <span className="text-xs font-semibold">{act.label}</span>
                <span className="text-[9px] opacity-70 font-mono hidden xs:inline">{act.sub}</span>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
