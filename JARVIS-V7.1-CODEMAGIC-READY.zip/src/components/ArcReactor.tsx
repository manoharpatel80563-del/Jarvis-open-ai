import React from 'react';
import { Mic, MicOff, Square, Volume2, Sparkles, Radio } from 'lucide-react';
import { AssistantState } from '../types';

interface ArcReactorProps {
  state: AssistantState;
  transcript: string;
  isInterim: boolean;
  onMicClick: () => void;
  onStopSpeaking: () => void;
  language: string;
  errorMessage?: string;
  continuousMode: boolean;
  onToggleContinuousMode: () => void;
  wakeWordEnabled: boolean;
  onToggleWakeWord: () => void;
}

export const ArcReactor: React.FC<ArcReactorProps> = ({
  state,
  transcript,
  isInterim,
  onMicClick,
  onStopSpeaking,
  language,
  errorMessage,
  continuousMode,
  onToggleContinuousMode,
  wakeWordEnabled,
  onToggleWakeWord,
}) => {
  const isListening = state === 'listening';
  const isProcessing = state === 'processing';
  const isSpeaking = state === 'speaking';
  const isRestarting = state === 'restarting';

  // Status text in exact accordance with JARVIS V6 State Machine requirements
  let statusBadge = {
    text: 'JARVIS STANDBY',
    subText: continuousMode ? 'Continuous Mode Active • Say "Hey Jarvis"' : 'Tap mic or say "Hey Jarvis"',
    color: 'border-cyan-500/40 text-cyan-400 bg-cyan-950/40',
    dotColor: 'bg-cyan-400',
  };

  if (isListening) {
    statusBadge = {
      text: 'JARVIS IS LISTENING',
      subText: 'Microphone active • Speak in Hindi, Hinglish, or English',
      color: 'border-amber-500/50 text-amber-300 bg-amber-950/50 shadow-[0_0_15px_rgba(245,158,11,0.25)]',
      dotColor: 'bg-amber-400 animate-ping',
    };
  } else if (isProcessing) {
    statusBadge = {
      text: 'JARVIS IS THINKING',
      subText: 'Processing command & Gemini neural response...',
      color: 'border-violet-500/50 text-violet-300 bg-violet-950/50 shadow-[0_0_15px_rgba(139,92,246,0.25)]',
      dotColor: 'bg-violet-400 animate-spin',
    };
  } else if (isSpeaking) {
    statusBadge = {
      text: 'JARVIS IS SPEAKING',
      subText: 'Vocalizing response • Microphone paused',
      color: 'border-emerald-500/50 text-emerald-300 bg-emerald-950/50 shadow-[0_0_15px_rgba(16,185,129,0.25)]',
      dotColor: 'bg-emerald-400 animate-pulse',
    };
  } else if (isRestarting) {
    statusBadge = {
      text: 'JARVIS IS RESTARTING',
      subText: 'Resuming microphone for continuous conversation...',
      color: 'border-sky-500/50 text-sky-300 bg-sky-950/50 shadow-[0_0_15px_rgba(14,165,233,0.25)]',
      dotColor: 'bg-sky-400 animate-ping',
    };
  }

  return (
    <div className="flex flex-col items-center justify-center my-4 sm:my-6 w-full max-w-md mx-auto px-4 select-none">
      {/* Outer Holographic Reactor Container */}
      <div className="relative flex items-center justify-center w-56 h-56 sm:w-64 sm:h-64">
        {/* Ambient Glow Aura */}
        <div
          className={`absolute inset-0 rounded-full transition-all duration-700 blur-2xl opacity-40 ${
            isListening
              ? 'bg-amber-500 scale-110'
              : isProcessing
              ? 'bg-violet-600 scale-105'
              : isSpeaking
              ? 'bg-emerald-500 scale-110'
              : 'bg-cyan-500 scale-100'
          }`}
        />

        {/* Outer Ring with Rotating HUD Ticks */}
        <svg
          className={`absolute inset-0 w-full h-full transition-transform duration-1000 ${
            isProcessing ? 'animate-spin' : isListening ? 'animate-[spin_4s_linear_infinite]' : 'animate-[spin_24s_linear_infinite]'
          }`}
          viewBox="0 0 200 200"
        >
          {/* Outer Dashed Orbit */}
          <circle
            cx="100"
            cy="100"
            r="94"
            fill="none"
            stroke={isListening ? '#f59e0b' : isSpeaking ? '#10b981' : isProcessing ? '#a855f7' : '#06b6d4'}
            strokeWidth="1.5"
            strokeDasharray="4 8"
            opacity="0.5"
          />
          {/* Arc segments */}
          <circle
            cx="100"
            cy="100"
            r="86"
            fill="none"
            stroke={isListening ? '#fbbf24' : '#00f0ff'}
            strokeWidth="2"
            strokeDasharray="25 45 60 30"
            opacity="0.75"
          />
        </svg>

        {/* Middle Counter-Rotating Ring */}
        <svg
          className={`absolute inset-4 w-[calc(100%-2rem)] h-[calc(100%-2rem)] transition-transform duration-700 ${
            isProcessing
              ? 'animate-[spin_2s_linear_infinite_reverse]'
              : isListening
              ? 'animate-[spin_6s_linear_infinite_reverse]'
              : 'animate-[spin_32s_linear_infinite_reverse]'
          }`}
          viewBox="0 0 160 160"
        >
          <circle
            cx="80"
            cy="80"
            r="74"
            fill="none"
            stroke={isListening ? '#f59e0b' : isProcessing ? '#8b5cf6' : '#0284c7'}
            strokeWidth="1"
            strokeDasharray="12 18"
            opacity="0.6"
          />
          <circle
            cx="80"
            cy="80"
            r="66"
            fill="none"
            stroke={isSpeaking ? '#34d399' : '#38bdf8'}
            strokeWidth="1.5"
            strokeDasharray="40 80"
            opacity="0.8"
          />
        </svg>

        {/* Pulse Ripple when Listening */}
        {isListening && (
          <>
            <div className="absolute inset-8 rounded-full border border-amber-400/50 animate-ping opacity-75 pointer-events-none" />
            <div className="absolute inset-4 rounded-full border border-amber-500/30 animate-pulse pointer-events-none" />
          </>
        )}

        {/* Pulse Ripple when Speaking */}
        {isSpeaking && (
          <div className="absolute inset-6 rounded-full border border-emerald-400/40 animate-ping opacity-60 pointer-events-none" />
        )}

        {/* Central Core Interactive Button */}
        <button
          id="btn-jarvis-arc-core"
          type="button"
          onClick={() => {
            if (isSpeaking) {
              onStopSpeaking();
            } else {
              onMicClick();
            }
          }}
          aria-label={
            isListening
              ? 'Stop listening'
              : isSpeaking
              ? 'Stop speaking'
              : isProcessing
              ? 'JARVIS processing'
              : 'Start voice command'
          }
          className={`relative z-10 flex flex-col items-center justify-center w-28 h-28 sm:w-32 sm:h-32 rounded-full border-2 transition-all duration-300 shadow-2xl focus:outline-none ${
            isListening
              ? 'border-amber-400 bg-amber-950/80 text-amber-300 shadow-[0_0_35px_rgba(245,158,11,0.6)] scale-105 ring-4 ring-amber-500/30'
              : isProcessing
              ? 'border-violet-400 bg-violet-950/80 text-violet-300 shadow-[0_0_35px_rgba(139,92,246,0.6)] animate-pulse'
              : isSpeaking
              ? 'border-emerald-400 bg-emerald-950/80 text-emerald-300 shadow-[0_0_35px_rgba(16,185,129,0.6)] scale-105'
              : 'border-cyan-400/80 bg-gray-950/90 text-cyan-300 shadow-[0_0_30px_rgba(6,182,212,0.4)] hover:shadow-[0_0_40px_rgba(6,182,212,0.6)] hover:border-cyan-300 active:scale-95'
          }`}
        >
          {/* Inner Reactor Geometric Ring */}
          <div className="absolute inset-1.5 rounded-full border border-cyan-400/20 pointer-events-none" />

          {/* Center Dynamic Icon */}
          <div className="flex items-center justify-center">
            {isListening ? (
              <div className="flex flex-col items-center">
                <Mic className="w-9 h-9 sm:w-10 sm:h-10 text-amber-300 animate-pulse" />
                <span className="text-[10px] uppercase font-bold tracking-widest text-amber-400 mt-1">
                  TAP TO STOP
                </span>
              </div>
            ) : isProcessing ? (
              <div className="flex flex-col items-center">
                <Sparkles className="w-9 h-9 sm:w-10 sm:h-10 text-violet-300 animate-spin" />
                <span className="text-[10px] uppercase font-bold tracking-widest text-violet-300 mt-1">
                  THINKING
                </span>
              </div>
            ) : isSpeaking ? (
              <div className="flex flex-col items-center">
                <Square className="w-8 h-8 sm:w-9 sm:h-9 text-emerald-300 fill-emerald-300/40" />
                <span className="text-[10px] uppercase font-bold tracking-widest text-emerald-400 mt-1">
                  STOP AUDIO
                </span>
              </div>
            ) : (
              <div className="flex flex-col items-center">
                <Mic className="w-9 h-9 sm:w-10 sm:h-10 text-cyan-300 group-hover:scale-110 transition-transform" />
                <span className="text-[10px] uppercase font-bold tracking-widest text-cyan-400 mt-1">
                  START MIC
                </span>
              </div>
            )}
          </div>

          {/* Sound Wave Bars when Speaking or Listening */}
          {(isListening || isSpeaking) && (
            <div className="flex items-center gap-1 mt-1.5">
              <span className={`w-1 h-3 rounded-full animate-[bounce_0.6s_infinite_100ms] ${isListening ? 'bg-amber-400' : 'bg-emerald-400'}`} />
              <span className={`w-1 h-5 rounded-full animate-[bounce_0.6s_infinite_200ms] ${isListening ? 'bg-amber-400' : 'bg-emerald-400'}`} />
              <span className={`w-1 h-4 rounded-full animate-[bounce_0.6s_infinite_300ms] ${isListening ? 'bg-amber-400' : 'bg-emerald-400'}`} />
              <span className={`w-1 h-6 rounded-full animate-[bounce_0.6s_infinite_150ms] ${isListening ? 'bg-amber-400' : 'bg-emerald-400'}`} />
              <span className={`w-1 h-3 rounded-full animate-[bounce_0.6s_infinite_250ms] ${isListening ? 'bg-amber-400' : 'bg-emerald-400'}`} />
            </div>
          )}
        </button>
      </div>

      {/* Dynamic Status Badge */}
      <div className={`mt-3 px-3 py-1 rounded-full border text-xs font-mono flex items-center gap-2 transition-all ${statusBadge.color}`}>
        <span className={`w-2 h-2 rounded-full ${statusBadge.dotColor}`} />
        <span className="font-semibold tracking-wider">{statusBadge.text}</span>
      </div>
      <p className="text-[11px] text-cyan-500/70 font-mono mt-0.5">{statusBadge.subText}</p>

      {/* Error Notice if any */}
      {errorMessage && (
        <div className="w-full mt-3 p-2.5 rounded-lg border border-red-500/40 bg-red-950/60 text-red-200 text-xs font-mono text-center flex flex-col items-center gap-1">
          <span className="font-bold text-red-400">⚠️ Audio Sensor Notice</span>
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Live Transcript / Recognized Command HUD Panel */}
      <div className="w-full mt-3 p-3 rounded-xl border border-cyan-500/20 bg-gray-900/60 backdrop-blur-sm">
        <div className="flex items-center justify-between text-[11px] text-cyan-400/80 font-mono uppercase border-b border-cyan-900/40 pb-1 mb-1.5">
          <span>{isListening ? 'LIVE VOICE TRANSCRIPT' : 'LATEST VOICE INPUT'}</span>
          <span className="text-[10px] text-cyan-500/60">
            {language === 'hi-IN' ? '🇮🇳 हिन्दी (hi-IN)' : language}
          </span>
        </div>
        <p className="text-sm sm:text-base text-cyan-100 font-medium min-h-[1.5rem] break-words">
          {transcript ? (
            <span>
              "{transcript}"
              {isInterim && <span className="inline-block w-2 h-4 ml-1 bg-cyan-400 animate-pulse align-middle" />}
            </span>
          ) : (
            <span className="text-cyan-600/70 italic">
              {isListening ? 'Listening for your voice... speak now' : 'Ready for your command. Tap the core or say "समय बताओ"...'}
            </span>
          )}
        </p>
      </div>

      {/* Continuous Conversation Mode Control */}
      <div className="w-full mt-3 p-2.5 rounded-xl border border-cyan-500/30 bg-gray-950/80 backdrop-blur-md flex items-center justify-between gap-2 shadow-[0_4px_20px_rgba(0,0,0,0.4)]">
        <div className="flex items-center gap-2.5 min-w-0">
          <div
            className={`w-3 h-3 rounded-full flex-shrink-0 transition-colors ${
              continuousMode ? 'bg-emerald-400 shadow-[0_0_8px_#34d399] animate-pulse' : 'bg-gray-600'
            }`}
          />
          <div className="flex flex-col min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs font-mono font-bold tracking-wider text-cyan-200 truncate">
                Continuous Conversation
              </span>
              {continuousMode && (
                <span className="text-[10px] font-mono font-bold tracking-widest px-2 py-0.5 rounded-full bg-emerald-950/90 border border-emerald-500/60 text-emerald-300 animate-pulse">
                  CONVERSATION MODE
                </span>
              )}
            </div>
            <span className="text-[10px] text-cyan-400/70 font-mono truncate">
              {continuousMode
                ? 'Loop active: Speak → JARVIS replies → Auto-listens'
                : 'Tap to toggle hands-free live conversation loop'}
            </span>
          </div>
        </div>

        <button
          id="btn-toggle-continuous-mode"
          type="button"
          onClick={onToggleContinuousMode}
          className={`flex-shrink-0 px-3 py-1.5 rounded-lg text-xs font-mono font-bold tracking-wider transition-all duration-300 border ${
            continuousMode
              ? 'border-emerald-500 bg-emerald-950/70 text-emerald-300 shadow-[0_0_15px_rgba(16,185,129,0.3)] hover:bg-emerald-900/70'
              : 'border-cyan-500/40 bg-cyan-950/30 text-cyan-300 hover:border-cyan-400 hover:bg-cyan-950/60'
          }`}
        >
          {continuousMode ? 'ACTIVE' : 'START'}
        </button>
      </div>

      {/* Wake Word Status & Quick Toggle */}
      <div className="w-full mt-2 px-3 py-2 rounded-xl border border-cyan-500/20 bg-gray-950/60 backdrop-blur-sm flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Radio
            className={`w-3.5 h-3.5 ${
              wakeWordEnabled
                ? isListening
                  ? 'text-amber-400 animate-ping'
                  : 'text-cyan-400 animate-pulse'
                : 'text-gray-500'
            }`}
          />
          <span className="text-xs font-mono font-bold">
            {wakeWordEnabled
              ? isListening
                ? 'Listening...'
                : 'Wake Word: ON'
              : 'Wake Word: OFF'}
          </span>
          <span className="text-[10px] text-cyan-500/70 hidden xs:inline">
            {wakeWordEnabled ? '("Hey Jarvis")' : '(Muted)'}
          </span>
        </div>

        <button
          id="btn-toggle-wakeword-hud"
          type="button"
          onClick={onToggleWakeWord}
          className={`px-2.5 py-1 rounded-md text-[11px] font-mono font-bold transition-all border ${
            wakeWordEnabled
              ? 'border-cyan-500/60 bg-cyan-950/80 text-cyan-300 shadow-[0_0_10px_rgba(6,182,212,0.25)] hover:bg-cyan-900/80'
              : 'border-gray-800 bg-gray-900/80 text-gray-400 hover:text-gray-200'
          }`}
        >
          {wakeWordEnabled ? 'ON' : 'OFF'}
        </button>
      </div>

      {/* Secondary Quick Stop/Start Controls for Accessibility */}
      <div className="flex items-center gap-2 mt-2 w-full justify-center">
        {isListening ? (
          <button
            id="btn-voice-stop-listening"
            type="button"
            onClick={onMicClick}
            className="flex items-center gap-1.5 px-4 py-2 rounded-lg border border-amber-500/60 bg-amber-950/50 text-amber-300 text-xs font-mono font-bold hover:bg-amber-900/50 transition-all shadow-[0_0_12px_rgba(245,158,11,0.2)]"
          >
            <MicOff className="w-3.5 h-3.5" />
            <span>Stop Recording</span>
          </button>
        ) : (
          <button
            id="btn-voice-start-listening"
            type="button"
            onClick={onMicClick}
            className="flex items-center gap-1.5 px-4 py-2 rounded-lg border border-cyan-500/40 bg-cyan-950/40 text-cyan-300 text-xs font-mono font-bold hover:bg-cyan-900/50 transition-all hover:border-cyan-400"
          >
            <Mic className="w-3.5 h-3.5" />
            <span>Activate Voice (बोलें)</span>
          </button>
        )}

        {isSpeaking && (
          <button
            id="btn-voice-stop-speaking"
            type="button"
            onClick={onStopSpeaking}
            className="flex items-center gap-1.5 px-4 py-2 rounded-lg border border-emerald-500/60 bg-emerald-950/50 text-emerald-300 text-xs font-mono font-bold hover:bg-emerald-900/50 transition-all shadow-[0_0_12px_rgba(16,185,129,0.2)]"
          >
            <Volume2 className="w-3.5 h-3.5" />
            <span>Mute Voice (शांत करें)</span>
          </button>
        )}
      </div>
    </div>
  );
};
