import React, { useState, useEffect, useMemo } from 'react';
import {
  X,
  Settings,
  Mic,
  Volume2,
  Globe,
  Radio,
  Smartphone,
  Download,
  Zap,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Save,
  Sliders,
  Sparkles,
  Wifi,
  WifiOff,
} from 'lucide-react';
import { AppSettings } from '../types';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onUpdateSettings: (newSettings: Partial<AppSettings>) => void;
  onSaveSettings: (settingsToSave: AppSettings) => void;
  availableVoices: SpeechSynthesisVoice[];
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  onSaveSettings,
  availableVoices,
}) => {
  // Local working copy of settings so changes can be tested and saved cleanly
  const [localSettings, setLocalSettings] = useState<AppSettings>(settings);
  const [testStatus, setTestStatus] = useState<'idle' | 'testing' | 'success' | 'error'>('idle');
  const [testResultMsg, setTestResultMsg] = useState<string>('');
  const [saveSuccessNotice, setSaveSuccessNotice] = useState<boolean>(false);

  useEffect(() => {
    if (isOpen) {
      setLocalSettings(settings);
      setTestStatus('idle');
      setTestResultMsg('');
      setSaveSuccessNotice(false);
    }
  }, [isOpen, settings]);

  const uniqueVoices = useMemo(() => {
    if (!availableVoices || availableVoices.length === 0) return [];
    const seen = new Set<string>();
    const result: SpeechSynthesisVoice[] = [];
    for (const v of availableVoices) {
      const key = (v.voiceURI || v.name || '').trim().toLowerCase();
      if (!seen.has(key)) {
        seen.add(key);
        result.push(v);
      }
    }
    return result;
  }, [availableVoices]);

  // Test AI Connection function
  const handleTestConnection = async () => {
    setTestStatus('testing');
    setTestResultMsg('Pinging AI Brain...');
    const startTime = performance.now();

    try {
      const rawEndpoint = localSettings.apiEndpoint?.trim();
      let targetUrl = '/api/health';
      if (rawEndpoint) {
        const cleanBase = rawEndpoint.replace(/\/api\/(chat|health)(\/stream)?$/, '').replace(/\/$/, '');
        targetUrl = `${cleanBase}/api/health`;
      }

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 6000);

      const res = await fetch(targetUrl, {
        method: 'GET',
        headers: { Accept: 'application/json' },
        signal: controller.signal,
      });

      clearTimeout(timeoutId);
      const latency = Math.round(performance.now() - startTime);

      if (res.ok) {
        const data = await res.json().catch(() => ({}));
        setTestStatus('success');
        setTestResultMsg(`Connected! Status: ${data.status || 'online'} (${latency}ms round-trip)`);
      } else {
        setTestStatus('error');
        setTestResultMsg(`Server returned status ${res.status}. Check URL or backend.`);
      }
    } catch (err: any) {
      const isTimeout = err?.name === 'AbortError';
      setTestStatus('error');
      setTestResultMsg(isTimeout ? 'Connection timed out after 6 seconds.' : `Failed to connect: ${err?.message || 'Network unreachable'}`);
    }
  };

  const handleSave = () => {
    onSaveSettings(localSettings);
    setSaveSuccessNotice(true);
    setTimeout(() => {
      setSaveSuccessNotice(false);
      onClose();
    }, 900);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in select-none">
      <div className="relative w-full max-w-lg max-h-[92vh] flex flex-col rounded-2xl border border-cyan-500/50 bg-gray-950 p-4 sm:p-5 text-cyan-50 shadow-[0_0_50px_rgba(6,182,212,0.35)]">
        {/* Header Bar */}
        <div className="flex items-center justify-between border-b border-cyan-900/60 pb-3 mb-3">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-cyan-950/80 border border-cyan-500/40 text-cyan-300">
              <Settings className="w-5 h-5 animate-[spin_16s_linear_infinite]" />
            </div>
            <div>
              <h3 className="text-base font-black font-['Orbitron'] tracking-wider text-cyan-200">
                JARVIS V7 SETTINGS
              </h3>
              <p className="text-[10px] font-mono text-cyan-400/80">
                Configure AI Brain, Voice, Wake Word & Offline Mode
              </p>
            </div>
          </div>

          <button
            id="btn-close-settings-modal"
            type="button"
            onClick={onClose}
            aria-label="Close Settings"
            className="p-2 rounded-lg border border-cyan-900 bg-gray-900 text-cyan-400 hover:bg-cyan-900/60 hover:text-cyan-200 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Form Content */}
        <div className="flex-1 overflow-y-auto pr-1.5 space-y-3.5 font-mono text-xs custom-scrollbar">
          {/* SECTION 1: REAL ONLINE AI BRAIN CONFIGURATION */}
          <div className="p-3.5 rounded-xl border border-cyan-500/40 bg-gradient-to-br from-cyan-950/40 via-gray-900/70 to-gray-950 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-cyan-300 font-bold">
                <Globe className="w-4 h-4 text-cyan-400" />
                <span className="text-xs tracking-wider">ONLINE AI SERVER URL</span>
              </div>
              <span className="text-[9px] px-2 py-0.5 rounded-full border border-cyan-500/40 bg-cyan-900/30 text-cyan-300">
                GEMINI AI BRAIN
              </span>
            </div>

            <div className="space-y-1">
              <label className="text-[11px] text-cyan-300/90 font-medium">
                Backend Server Address
              </label>
              <input
                id="input-settings-server-url"
                type="text"
                placeholder="https://your-jarvis-server.run.app (Leave empty for default)"
                value={localSettings.apiEndpoint || ''}
                onChange={(e) => setLocalSettings({ ...localSettings, apiEndpoint: e.target.value })}
                className="w-full bg-gray-950 border border-cyan-800 rounded-lg p-2.5 text-cyan-100 placeholder-cyan-800 focus:outline-none focus:border-cyan-400 font-mono text-xs"
              />
              <p className="text-[10px] text-cyan-500/80 font-sans leading-relaxed">
                Enter your cloud AI server URL. In APK or offline, local device commands (torch, volume, apps, dialer) remain active even without a server.
              </p>
            </div>

            {/* AI Model Selection */}
            <div className="space-y-1 pt-1">
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-cyan-300/90">AI Model Protocol</span>
                <span className="text-cyan-400 text-[10px]">Ultra-Fast Gemini</span>
              </div>
              <select
                id="select-ai-model"
                value={localSettings.aiModel || 'auto'}
                onChange={(e) => setLocalSettings({ ...localSettings, aiModel: e.target.value })}
                className="w-full bg-gray-950 border border-cyan-900 rounded-lg p-2 text-cyan-100 focus:outline-none focus:border-cyan-400 text-xs"
              >
                <option value="auto">⚡ Auto High-Availability (Auto selects active Gemini brain)</option>
                <option value="gemini-3.5-flash">Gemini 3.5 Flash (Ultra Reliable & Fast)</option>
                <option value="gemini-3.1-flash-lite">Gemini 3.1 Flash Lite (Lowest Latency)</option>
                <option value="gemini-3.8-flash">Gemini 3.8 Flash</option>
              </select>
            </div>

            {/* Test Connection Button & Live Ping Display */}
            <div className="pt-1 flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
              <button
                id="btn-test-ai-connection"
                type="button"
                onClick={handleTestConnection}
                disabled={testStatus === 'testing'}
                className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg border border-cyan-400/80 bg-cyan-950/70 hover:bg-cyan-900/80 text-cyan-200 text-xs font-bold transition-all disabled:opacity-50"
              >
                {testStatus === 'testing' ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin text-cyan-300" />
                ) : (
                  <Zap className="w-3.5 h-3.5 text-cyan-400" />
                )}
                <span>Test AI Connection</span>
              </button>

              {testResultMsg && (
                <div
                  className={`flex-1 flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-[11px] ${
                    testStatus === 'success'
                      ? 'border-emerald-500/50 bg-emerald-950/50 text-emerald-300'
                      : testStatus === 'error'
                      ? 'border-red-500/50 bg-red-950/50 text-red-300'
                      : 'border-cyan-500/30 bg-cyan-950/40 text-cyan-300'
                  }`}
                >
                  {testStatus === 'success' && <CheckCircle2 className="w-3.5 h-3.5 flex-shrink-0 text-emerald-400" />}
                  {testStatus === 'error' && <AlertCircle className="w-3.5 h-3.5 flex-shrink-0 text-red-400" />}
                  <span className="truncate">{testResultMsg}</span>
                </div>
              )}
            </div>
          </div>

          {/* SECTION 2: ONLINE / OFFLINE OPERATIONAL MODE */}
          <div className="p-3.5 rounded-xl border border-cyan-950 bg-gray-900/60 space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-cyan-300 font-bold">
                {localSettings.offlineOnlyMode ? (
                  <WifiOff className="w-4 h-4 text-amber-400" />
                ) : (
                  <Wifi className="w-4 h-4 text-cyan-400" />
                )}
                <span className="text-xs">MODE: {localSettings.offlineOnlyMode ? 'STRICT OFFLINE' : 'ONLINE AI + OFFLINE HYBRID'}</span>
              </div>
              <input
                id="toggle-offline-only-mode"
                type="checkbox"
                checked={!localSettings.offlineOnlyMode}
                onChange={(e) => setLocalSettings({ ...localSettings, offlineOnlyMode: !e.target.checked })}
                className="w-4 h-4 accent-cyan-500 rounded cursor-pointer"
              />
            </div>
            <p className="text-[10px] text-cyan-500/80 font-sans leading-relaxed">
              {localSettings.offlineOnlyMode
                ? 'Strict Offline active: Only local hardware commands (flashlight, volume, apps, dialer) are executed. No AI server calls.'
                : 'Hybrid active: Smart router runs hardware commands locally, and routes general questions & conversation to the online AI brain.'}
            </p>
          </div>

          {/* SECTION 3: WAKE WORD CONTROLS & SENSITIVITY */}
          <div className="p-3.5 rounded-xl border border-cyan-500/30 bg-cyan-950/20 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-cyan-300 font-bold">
                <Radio className="w-4 h-4 text-cyan-400 animate-pulse" />
                <span className="text-xs">"HEY JARVIS" WAKE WORD</span>
              </div>
              <input
                id="checkbox-settings-wake-word"
                type="checkbox"
                checked={localSettings.wakeWordEnabled ?? true}
                onChange={(e) => setLocalSettings({ ...localSettings, wakeWordEnabled: e.target.checked })}
                className="w-4 h-4 accent-cyan-500 rounded cursor-pointer"
              />
            </div>
            <p className="text-[10px] text-cyan-400/80 font-sans leading-relaxed">
              When ON, JARVIS continuously listens for "Hey Jarvis" or "हे जार्विस" and wakes up hands-free. State is permanently saved.
            </p>

            {/* Wake Word Sensitivity Slider */}
            <div className="space-y-1 pt-1 border-t border-cyan-950/80">
              <div className="flex justify-between text-[11px]">
                <span className="text-cyan-400/90 flex items-center gap-1">
                  <Sliders className="w-3 h-3 text-cyan-400" />
                  Sensitivity Level
                </span>
                <span className="text-cyan-300 font-bold">
                  {localSettings.wakeWordSensitivity === 1
                    ? 'Low'
                    : localSettings.wakeWordSensitivity === 5
                    ? 'High'
                    : 'Balanced (3)'}
                </span>
              </div>
              <input
                id="slider-wake-sensitivity"
                type="range"
                min="1"
                max="5"
                step="1"
                value={localSettings.wakeWordSensitivity ?? 3}
                onChange={(e) => setLocalSettings({ ...localSettings, wakeWordSensitivity: parseInt(e.target.value) })}
                className="w-full accent-cyan-500 cursor-pointer"
              />
              <div className="flex justify-between text-[9px] text-cyan-600">
                <span>Low (Quiet room)</span>
                <span>Balanced</span>
                <span>High (Noisy room)</span>
              </div>
            </div>
          </div>

          {/* SECTION 4: LANGUAGE & VOICE RECOGNITION (STT) */}
          <div className="p-3.5 rounded-xl border border-cyan-950 bg-gray-900/60 space-y-2">
            <div className="flex items-center gap-2 text-cyan-300 font-bold">
              <Mic className="w-4 h-4 text-cyan-400" />
              <span className="text-xs">VOICE RECOGNITION (HINDI / EN / AUTO)</span>
            </div>
            <select
              id="select-settings-stt-lang"
              value={localSettings.sttLanguage}
              onChange={(e) => setLocalSettings({ ...localSettings, sttLanguage: e.target.value as any })}
              className="w-full bg-gray-950 border border-cyan-900 rounded-lg p-2.5 text-cyan-100 focus:outline-none focus:border-cyan-400 text-xs"
            >
              <option value="hi-IN">🇮🇳 हिन्दी / Hinglish (hi-IN) — Recommended</option>
              <option value="en-IN">🇮🇳 English (India) (en-IN)</option>
              <option value="en-US">🇺🇸 English (US) (en-US)</option>
              <option value="auto">🌐 Auto-Detect Language</option>
            </select>
            <p className="text-[10px] text-cyan-500/80 font-sans">
              *Hindi (hi-IN) naturally understands bilingual Hindi, Hinglish, and English spoken commands.
            </p>
          </div>

          {/* SECTION 5: VOICE SYNTHESIS (TTS) & STREAMING SPEED */}
          <div className="p-3.5 rounded-xl border border-cyan-950 bg-gray-900/60 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-cyan-300 font-bold">
                <Volume2 className="w-4 h-4 text-cyan-400" />
                <span className="text-xs">VOICE RESPONSE (TTS)</span>
              </div>
              <input
                id="checkbox-settings-auto-speak"
                type="checkbox"
                checked={localSettings.autoSpeak}
                onChange={(e) => setLocalSettings({ ...localSettings, autoSpeak: e.target.checked })}
                className="w-4 h-4 accent-cyan-500 rounded cursor-pointer"
              />
            </div>

            {/* Fast Streaming AI Option */}
            <div className="flex items-center justify-between pt-1 border-t border-cyan-950">
              <div className="space-y-0.5">
                <span className="text-[11px] text-cyan-300/90 font-bold flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-cyan-400" />
                  Streaming Voice & Text Response
                </span>
                <p className="text-[10px] text-cyan-500/80 font-sans">
                  Starts displaying and vocalizing sentences immediately as generated.
                </p>
              </div>
              <input
                id="checkbox-settings-streaming"
                type="checkbox"
                checked={localSettings.enableStreaming ?? true}
                onChange={(e) => setLocalSettings({ ...localSettings, enableStreaming: e.target.checked })}
                className="w-4 h-4 accent-cyan-500 rounded cursor-pointer"
              />
            </div>

            {/* Speech Rate Slider */}
            <div className="space-y-1">
              <div className="flex justify-between text-[11px]">
                <span className="text-cyan-400/90">Speaking Speed</span>
                <span className="text-cyan-300 font-bold">{localSettings.speechRate.toFixed(1)}x</span>
              </div>
              <input
                id="slider-settings-speech-rate"
                type="range"
                min="0.8"
                max="1.5"
                step="0.1"
                value={localSettings.speechRate}
                onChange={(e) => setLocalSettings({ ...localSettings, speechRate: parseFloat(e.target.value) })}
                className="w-full accent-cyan-500 cursor-pointer"
              />
            </div>

            {/* Voice Dropdown */}
            {uniqueVoices.length > 0 && (
              <div className="space-y-1">
                <label className="text-[11px] text-cyan-400/90">Preferred Voice</label>
                <select
                  id="select-settings-voice"
                  value={localSettings.voiceURI}
                  onChange={(e) => setLocalSettings({ ...localSettings, voiceURI: e.target.value })}
                  className="w-full bg-gray-950 border border-cyan-900 rounded-lg p-2 text-cyan-100 focus:outline-none focus:border-cyan-400 text-[11px] truncate"
                >
                  <option value="">Auto-select clearest voice (Hindi / English)</option>
                  {uniqueVoices.map((v, idx) => (
                    <option key={`v-${idx}-${v.voiceURI || v.name}`} value={v.voiceURI}>
                      {v.name} ({v.lang})
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>

          {/* SECTION 6: GOOGLE SEARCH GROUNDING */}
          <div className="p-3.5 rounded-xl border border-cyan-950 bg-gray-900/60 flex items-center justify-between">
            <div className="space-y-0.5">
              <div className="flex items-center gap-2 text-cyan-300 font-bold">
                <Globe className="w-4 h-4 text-cyan-400" />
                <span className="text-xs">GOOGLE SEARCH GROUNDING</span>
              </div>
              <p className="text-[10px] text-cyan-500/80 font-sans">
                Fetches latest real-time facts and citations through Gemini.
              </p>
            </div>
            <input
              id="checkbox-settings-grounding"
              type="checkbox"
              checked={localSettings.enableSearchGrounding}
              onChange={(e) => setLocalSettings({ ...localSettings, enableSearchGrounding: e.target.checked })}
              className="w-4 h-4 accent-cyan-500 rounded cursor-pointer"
            />
          </div>

          {/* SECTION 7: ANDROID APK DIRECT DOWNLOAD */}
          <div className="p-3.5 rounded-xl border border-cyan-500/30 bg-gradient-to-r from-cyan-950/40 to-gray-900 flex items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-1.5 text-cyan-200 font-bold text-xs">
                <Smartphone className="w-4 h-4 text-cyan-400" />
                <span>JARVIS V6 ANDROID PACKAGE</span>
              </div>
              <p className="text-[10px] text-cyan-400/80 font-sans mt-0.5">
                Bundled offline app with hardware torch, volume & native wake word.
              </p>
            </div>
            <a
              id="link-settings-download-apk"
              href="/api/download-apk"
              download="jarvis-v6-debug.apk"
              className="flex items-center gap-1 px-3 py-1.5 rounded-lg border border-cyan-400 bg-cyan-950/80 text-cyan-200 text-xs font-bold hover:bg-cyan-900 transition-all flex-shrink-0"
            >
              <Download className="w-3.5 h-3.5" />
              <span>APK</span>
            </a>
          </div>
        </div>

        {/* Action Footer: Save Settings Button */}
        <div className="border-t border-cyan-900/70 pt-3 mt-3 flex items-center justify-between gap-2">
          {saveSuccessNotice ? (
            <div className="flex items-center gap-1.5 text-emerald-300 font-bold text-xs animate-pulse">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Settings Saved Successfully!</span>
            </div>
          ) : (
            <span className="text-[10px] text-cyan-500/70 font-mono hidden sm:inline">
              Preferences stored locally on this device.
            </span>
          )}

          <div className="flex items-center gap-2 ml-auto">
            <button
              id="btn-cancel-settings"
              type="button"
              onClick={onClose}
              className="px-3 py-2 rounded-lg border border-cyan-900 bg-gray-900 text-cyan-300 hover:bg-gray-800 text-xs font-mono font-medium"
            >
              Cancel
            </button>
            <button
              id="btn-save-settings"
              type="button"
              onClick={handleSave}
              className="flex items-center gap-1.5 px-4 py-2 rounded-lg border border-cyan-400 bg-gradient-to-r from-cyan-600 to-sky-600 hover:from-cyan-500 hover:to-sky-500 text-cyan-50 text-xs font-mono font-bold shadow-[0_0_15px_rgba(6,182,212,0.4)] active:scale-95 transition-all"
            >
              <Save className="w-4 h-4" />
              <span>Save Settings</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
