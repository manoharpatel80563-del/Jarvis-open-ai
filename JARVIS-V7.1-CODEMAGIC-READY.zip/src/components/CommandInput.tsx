import React, { useState } from 'react';
import { Send, Sparkles } from 'lucide-react';

interface CommandInputProps {
  onSubmit: (text: string) => void;
  disabled?: boolean;
  placeholder?: string;
}

export const CommandInput: React.FC<CommandInputProps> = ({
  onSubmit,
  disabled = false,
  placeholder = 'Type a command or ask JARVIS (Hindi / English)...',
}) => {
  const [value, setValue] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (value.trim() && !disabled) {
      onSubmit(value.trim());
      setValue('');
    }
  };

  return (
    <div className="w-full max-w-xl mx-auto px-4 pb-4 pt-1 sticky bottom-0 z-20 bg-gradient-to-t from-gray-950 via-gray-950/90 to-transparent">
      <form
        onSubmit={handleSubmit}
        className="flex items-center gap-2 rounded-2xl border border-cyan-500/30 bg-gray-900/90 backdrop-blur-md p-1.5 shadow-[0_0_20px_rgba(6,182,212,0.15)] focus-within:border-cyan-400 focus-within:shadow-[0_0_25px_rgba(6,182,212,0.3)] transition-all"
      >
        <div className="pl-2.5 text-cyan-400">
          <Sparkles className="w-4 h-4" />
        </div>
        <input
          id="input-text-command"
          type="text"
          value={value}
          onChange={(e) => setValue(e.target.value)}
          disabled={disabled}
          placeholder={placeholder}
          className="w-full bg-transparent text-sm text-cyan-100 placeholder:text-cyan-600/70 focus:outline-none px-1 py-1.5"
        />
        <button
          id="btn-submit-text-command"
          type="submit"
          disabled={!value.trim() || disabled}
          aria-label="Send command"
          className="flex items-center justify-center p-2.5 rounded-xl border border-cyan-500/50 bg-cyan-950/80 text-cyan-300 hover:bg-cyan-900/80 hover:text-cyan-100 disabled:opacity-40 disabled:pointer-events-none active:scale-95 transition-all"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
};
