export type AssistantState = 'idle' | 'listening' | 'processing' | 'speaking' | 'restarting' | 'wake_active' | 'stopped';

export interface GroundingSource {
  title: string;
  uri: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: string;
  isVoiceInput?: boolean;
  actionTaken?: string;
  actionUrl?: string;
  sources?: GroundingSource[];
  isError?: boolean;
}

export interface AppSettings {
  sttLanguage: 'hi-IN' | 'en-IN' | 'en-US' | 'auto';
  autoSpeak: boolean;
  speechRate: number; // 0.8 - 1.5
  speechPitch: number; // 0.8 - 1.2
  voiceURI: string;
  enableSearchGrounding: boolean;
  hapticFeedback: boolean;
  wakeWordEnabled: boolean;
  wakeWordSensitivity: number; // 1 to 5
  offlineOnlyMode: boolean;
  enableStreaming: boolean;
  apiEndpoint?: string;
  aiModel?: string;
}

export interface AndroidBridgeInterface {
  isNativeAndroid?: () => boolean;
  toggleFlashlight?: (enable: boolean) => boolean;
  isFlashlightActive?: () => boolean;
  setVolume?: (percentage: number) => number;
  adjustVolume?: (delta: number) => number;
  muteVolume?: () => boolean;
  openSettings?: (type: string) => boolean;
  launchApp?: (appName: string) => boolean;
  openDialer?: (phoneNumber: string) => boolean;
  openSms?: (phoneNumber: string, message: string) => boolean;
  openWhatsApp?: (phoneNumber: string, message: string) => boolean;
  controlMedia?: (action: string) => boolean;
  getBatteryLevel?: () => number;
  isBatteryCharging?: () => boolean;
  setWakeWordEnabled?: (enabled: boolean) => void;
  onAssistantSpeaking?: (isSpeaking: boolean) => void;
  vibrate?: (ms: number) => void;
  showToast?: (message: string) => void;
}

declare global {
  interface Window {
    AndroidBridge?: AndroidBridgeInterface;
    isJarvisAndroidApp?: boolean;
    onJarvisNativeWakeWordDetected?: () => void;
    onJarvisNativeVoiceCommand?: (cmd: string) => void;
  }
}

export interface BatteryInfo {
  supported: boolean;
  level: number; // 0 - 100
  charging: boolean;
}

export interface NetworkInfo {
  online: boolean;
  type?: string;
}
