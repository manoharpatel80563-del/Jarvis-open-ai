package com.jarvis.ai;

import android.content.ComponentName;
import android.service.voice.VoiceInteractionService;
import android.util.Log;

public class JarvisVoiceInteractionService extends VoiceInteractionService {
    private static final String TAG = "JarvisVoiceService";
    @Override public void onReady() {
        super.onReady();
        Log.i(TAG, "JARVIS voice assistant ready");
    }
    public static ComponentName getSessionServiceComponent(android.content.Context context) {
        return new ComponentName(context, JarvisVoiceInteractionSessionService.class);
    }
}
