package com.jarvis.ai;

import android.Manifest;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.json.JSONObject;

/**
 * Main Android Activity for JARVIS V6.
 * Hosts the full-screen futuristic Web UI inside a hardware-accelerated WebView,
 * binds the native Android device bridge, and manages WakeWordService.
 */
public class MainActivity extends Activity implements WakeWordService.WakeWordListener {

    private static final String TAG = "MainActivity";
    private static final int PERMISSION_REQUEST_CODE = 1001;

    // Bundled offline local HTML entry point inside APK assets
    private static final String LOCAL_ASSET_URL = "file:///android_asset/index.html";

    private WebView webView;
    private ProgressBar loadingBar;
    private JarvisAndroidBridge androidBridge;
    private WakeWordService wakeWordService;
    private boolean isServiceBound = false;
    private boolean isWakeWordActive = false;

    private final ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            WakeWordService.LocalBinder binder = (WakeWordService.LocalBinder) service;
            wakeWordService = binder.getService();
            wakeWordService.setListener(MainActivity.this);
            isServiceBound = true;
            Log.i(TAG, "WakeWordService connected successfully");
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            wakeWordService = null;
            isServiceBound = false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Make Activity fullscreen & match dark JARVIS theme
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(0xFF030712);
            getWindow().setNavigationBarColor(0xFF030712);
        }

        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.jarvisWebView);
        loadingBar = findViewById(R.id.jarvisLoadingBar);

        androidBridge = new JarvisAndroidBridge(this);

        checkRequiredPermissions();
        setupWebView();
        loadJarvisApp();
    }

    private void checkRequiredPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            String[] permissions;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                permissions = new String[]{
                        Manifest.permission.RECORD_AUDIO,
                        Manifest.permission.CAMERA,
                        Manifest.permission.POST_NOTIFICATIONS
                };
            } else {
                permissions = new String[]{
                        Manifest.permission.RECORD_AUDIO,
                        Manifest.permission.CAMERA
                };
            }

            boolean needsRequest = false;
            for (String perm : permissions) {
                if (checkSelfPermission(perm) != PackageManager.PERMISSION_GRANTED) {
                    needsRequest = true;
                    break;
                }
            }

            if (needsRequest) {
                requestPermissions(permissions, PERMISSION_REQUEST_CODE);
            }
        }
    }

    private void setupWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }

        // Expose Native Android Bridge
        webView.addJavascriptInterface(androidBridge, "AndroidBridge");

        // Custom WebChromeClient to auto-grant Web Speech & Audio recording
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    // Automatically grant audio and video permissions to JARVIS UI
                    request.grant(request.getResources());
                });
            }

            @Override
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                Log.d("JARVIS-WebConsole", consoleMessage.message() + " -- From line "
                        + consoleMessage.lineNumber() + " of " + consoleMessage.sourceId());
                return true;
            }
        });

        // WebViewClient to handle page lifecycle and external links
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                if (loadingBar != null) loadingBar.setVisibility(View.VISIBLE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (loadingBar != null) loadingBar.setVisibility(View.GONE);

                // Inject marker so React app knows it is in native Android container
                view.evaluateJavascript(
                        "window.isJarvisAndroidApp = true; " +
                        "window.dispatchEvent(new CustomEvent('jarvis-android-ready', { detail: { version: '7.1.0' } }));",
                        null
                );
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (request.isForMainFrame()) {
                    Log.w(TAG, "Failed loading remote URL, attempting local asset fallback");
                    view.loadUrl(LOCAL_ASSET_URL);
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleCustomUrls(request.getUrl().toString());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleCustomUrls(url);
            }
        });
    }

    private boolean handleCustomUrls(String url) {
        if (url == null) return false;
        try {
            if (url.startsWith("tel:") || url.startsWith("sms:") || 
                url.startsWith("smsto:") || url.startsWith("mailto:") || 
                url.startsWith("whatsapp:") || url.startsWith("intent:")) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                return true;
            }
        } catch (Exception e) {
            Log.e(TAG, "Error handling custom url: " + url, e);
        }
        return false;
    }

    private void loadJarvisApp() {
        Log.i(TAG, "Loading bundled offline JARVIS assets from " + LOCAL_ASSET_URL);
        webView.loadUrl(LOCAL_ASSET_URL);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            boolean micGranted = false;
            for (int i = 0; i < permissions.length; i++) {
                if (Manifest.permission.RECORD_AUDIO.equals(permissions[i]) &&
                        grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                    micGranted = true;
                }
            }
            if (!micGranted) {
                new android.app.AlertDialog.Builder(this)
                        .setTitle("Microphone Permission")
                        .setMessage("Microphone permission is required for voice commands and 'Hey Jarvis' wake word. You can enable it in Android Settings -> Apps -> JARVIS -> Permissions. Text commands and offline device controls remain fully active.")
                        .setPositiveButton("Understood", null)
                        .show();
            }
        }
    }

    // ==========================================
    // Wake Word Service Controls
    // ==========================================
    public synchronized void setWakeWordEnabled(boolean enabled) {
        if (this.isWakeWordActive == enabled && (isServiceBound == enabled)) {
            return; // Already in requested state
        }
        this.isWakeWordActive = enabled;
        try {
            getSharedPreferences("jarvis_prefs", MODE_PRIVATE)
                .edit()
                .putBoolean("wake_word_enabled", enabled)
                .apply();
        } catch (Exception ignored) {}

        Intent serviceIntent = new Intent(this, WakeWordService.class);
        try {
            if (enabled) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(serviceIntent);
                } else {
                    startService(serviceIntent);
                }
                if (!isServiceBound) {
                    bindService(serviceIntent, serviceConnection, Context.BIND_AUTO_CREATE);
                }
                androidBridge.showToast("JARVIS: 'Hey Jarvis' Wake Word active");
            } else {
                if (isServiceBound) {
                    try {
                        unbindService(serviceConnection);
                    } catch (Exception ignored) {}
                    isServiceBound = false;
                }
                stopService(serviceIntent);
                androidBridge.showToast("JARVIS: Wake Word disabled");
            }
        } catch (Exception e) {
            Log.e("MainActivity", "Error changing wake word state", e);
        }
    }

    public void setAssistantSpeaking(boolean isSpeaking) {
        if (wakeWordService != null) {
            wakeWordService.setPaused(isSpeaking);
        }
    }

    // WakeWordService.WakeWordListener
    @Override
    public void onWakeWordDetected() {
        runOnUiThread(() -> {
            androidBridge.vibrate(80);
            webView.evaluateJavascript(
                    "if (window.onJarvisNativeWakeWordDetected) { window.onJarvisNativeWakeWordDetected(); }",
                    null
            );
        });
    }

    @Override
    public void onNativeCommandReceived(String command) {
        runOnUiThread(() -> {
            String safeString = JSONObject.quote(command);
            webView.evaluateJavascript(
                    "if (window.onJarvisNativeVoiceCommand) { window.onJarvisNativeVoiceCommand(" + safeString + "); }",
                    null
            );
        });
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            // Minimize rather than killing the app so background wake word keeps running
            moveTaskToBack(true);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (isServiceBound) {
            unbindService(serviceConnection);
            isServiceBound = false;
        }
        if (webView != null) {
            webView.destroy();
        }
    }
}
