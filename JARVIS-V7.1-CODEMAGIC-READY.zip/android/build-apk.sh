#!/usr/bin/env bash
set -e

echo "=== JARVIS V7 Android APK Build System ==="

export JAVA_HOME="${JAVA_HOME:-/usr/lib/jvm/java-17-openjdk-amd64}"
export PATH="${JAVA_HOME}/bin:${PATH}"

ANDROID_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WEB_ROOT="$(cd "${ANDROID_ROOT}/.." && pwd)"
APP_DIR="${ANDROID_ROOT}/app"
GEN_DIR="${APP_DIR}/build/gen"
BIN_DIR="${APP_DIR}/build/bin"
COMPILED_RES_DIR="${APP_DIR}/build/compiled_res"
OUTPUT_DIR="${APP_DIR}/build/outputs/apk/debug"
ASSETS_DIR="${APP_DIR}/src/main/assets"

ANDROID_JAR="/opt/android-tools/android-35.jar"
if [ ! -f "${ANDROID_JAR}" ]; then
    ANDROID_JAR="/opt/android-tools/android-33.jar"
fi

AAPT2="/opt/android-tools/aapt2"
R8_JAR="/opt/android-tools/r8.jar"
KEYSTORE="/opt/android-tools/debug.keystore"

mkdir -p "${GEN_DIR}" "${BIN_DIR}" "${COMPILED_RES_DIR}" "${OUTPUT_DIR}" "${ASSETS_DIR}" "${WEB_ROOT}/public"

# Clean old artifacts
rm -rf "${GEN_DIR}"/* "${BIN_DIR}"/* "${COMPILED_RES_DIR}"/* "${OUTPUT_DIR}"/* "${ASSETS_DIR}"/*

# 1. Ensure debug keystore exists
if [ ! -f "${KEYSTORE}" ]; then
    echo "Creating debug keystore..."
    keytool -genkeypair -v -keystore "${KEYSTORE}" \
        -alias androiddebugkey -keyalg RSA -keysize 2048 -validity 10000 \
        -storepass android -keypass android -dname "CN=Android Debug,O=Android,C=US"
fi

# 2. Build and bundle local frontend assets inside APK
echo "[1/7] Building & packaging fresh local web assets..."
cd "${WEB_ROOT}"
npm run build

rm -rf "${ASSETS_DIR}"/*
cp -r "${WEB_ROOT}/dist"/* "${ASSETS_DIR}/"
# Remove backend server and archive artifacts from Android assets
rm -f "${ASSETS_DIR}/server.cjs" "${ASSETS_DIR}/server.cjs.map" "${ASSETS_DIR}"/*.apk "${ASSETS_DIR}"/*.zip 2>/dev/null || true

echo "Assets bundled: $(ls -A "${ASSETS_DIR}" | wc -l) files/directories"

# 3. Compile resources using modern AAPT2
echo "[2/7] Compiling Android resources with AAPT2..."
rm -f "${COMPILED_RES_DIR}/res.zip"
${AAPT2} compile --dir "${APP_DIR}/src/main/res" -o "${COMPILED_RES_DIR}/res.zip"

# 4. Link resources and bundle local assets
echo "[3/7] Linking resources & bundling assets with AAPT2..."
${AAPT2} link -I "${ANDROID_JAR}" \
    --manifest "${APP_DIR}/src/main/AndroidManifest.xml" \
    --java "${GEN_DIR}" \
    -A "${ASSETS_DIR}" \
    -o "${BIN_DIR}/res_linked.apk" \
    "${COMPILED_RES_DIR}/res.zip" \
    --auto-add-overlay

# 5. Compile Java sources
echo "[4/7] Compiling Java classes with javac..."
javac -source 1.8 -target 1.8 \
    -cp "${ANDROID_JAR}" \
    -d "${BIN_DIR}" \
    "${GEN_DIR}/com/jarvis/ai/R.java" \
    ${APP_DIR}/src/main/java/com/jarvis/ai/*.java

# 6. Convert class bytecode to Dalvik DEX via D8
echo "[5/7] Compiling bytecode into DEX with D8..."
java -cp "${R8_JAR}" com.android.tools.r8.D8 \
    --min-api 24 \
    --lib "${ANDROID_JAR}" \
    --output "${BIN_DIR}/" \
    ${BIN_DIR}/com/jarvis/ai/*.class

# 7. Package DEX into APK
echo "[6/7] Packaging classes.dex into APK..."
cp "${BIN_DIR}/res_linked.apk" "${BIN_DIR}/app.unaligned.apk"
cd "${BIN_DIR}"
zip -u app.unaligned.apk classes.dex

# 8. Align APK with zipalign (4-byte alignment)
echo "[7/7] Aligning and signing APK..."
zipalign -f -p 4 "${BIN_DIR}/app.unaligned.apk" "${BIN_DIR}/app.aligned.apk"

# 9. Sign APK with apksigner (v1, v2, v3 schemes for Android 7.0 - Android 16)
apksigner sign \
    --ks "${KEYSTORE}" \
    --ks-pass pass:android \
    --key-pass pass:android \
    --ks-key-alias androiddebugkey \
    --v1-signing-enabled true \
    --v2-signing-enabled true \
    --v3-signing-enabled true \
    --out "${OUTPUT_DIR}/app-debug.apk" \
    "${BIN_DIR}/app.aligned.apk"

# Verify signatures
echo "Verifying APK signatures..."
apksigner verify --verbose "${OUTPUT_DIR}/app-debug.apk"

# Copy final artifacts to distribution endpoints
cp "${OUTPUT_DIR}/app-debug.apk" "${ANDROID_ROOT}/jarvis-v7-debug.apk"
cp "${OUTPUT_DIR}/app-debug.apk" "${WEB_ROOT}/public/jarvis-v7-debug.apk"
cp "${OUTPUT_DIR}/app-debug.apk" "${ANDROID_ROOT}/jarvis-v6-debug.apk"
cp "${OUTPUT_DIR}/app-debug.apk" "${WEB_ROOT}/public/jarvis-v6-debug.apk"
mkdir -p "${ANDROID_ROOT}/dist"
cp "${OUTPUT_DIR}/app-debug.apk" "${ANDROID_ROOT}/dist/jarvis-v7-debug.apk"
cp "${OUTPUT_DIR}/app-debug.apk" "${ANDROID_ROOT}/dist/jarvis-v6-debug.apk"

# Also package project source ZIP for developers
echo "Generating project source ZIP..."
cd "${WEB_ROOT}"
zip -rq "${WEB_ROOT}/public/jarvis-v7-android-project.zip" \
    android/ \
    -x "android/app/build/*" \
    -x "android/**/.gradle/*" \
    -x "android/**/*.apk" \
    2>/dev/null || true
cp "${WEB_ROOT}/public/jarvis-v7-android-project.zip" "${WEB_ROOT}/public/jarvis-v6-android-project.zip" 2>/dev/null || true

APK_SIZE=$(ls -lh "${OUTPUT_DIR}/app-debug.apk" | awk '{print $5}')

echo "=============================================="
echo " BUILD SUCCESSFUL! JARVIS V7 APK READY"
echo " Size: ${APK_SIZE}"
echo " Targets: Android 7.0 (API 24) to Android 16 (API 35+)"
echo " Signatures: v1 + v2 + v3 (Fully Verified)"
echo " UI Bundled: file:///android_asset/index.html"
echo " Output files:"
echo " 1. ${OUTPUT_DIR}/app-debug.apk"
echo " 2. ${ANDROID_ROOT}/jarvis-v7-debug.apk"
echo " 3. /public/jarvis-v7-debug.apk"
echo "=============================================="
